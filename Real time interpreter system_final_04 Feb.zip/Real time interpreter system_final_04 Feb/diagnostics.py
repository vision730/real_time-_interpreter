#!/usr/bin/env python3
"""
Diagnostic tool to identify why translation fails on new GPU PC
Run this on the problematic machine to identify issues
"""

import os
import sys
import yaml
import torch
import numpy as np


def load_config():
    """Load and validate config.yaml"""
    try:
        with open("config.yaml", "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        print("✓ config.yaml loaded successfully")
        return cfg
    except Exception as e:
        print(f"✗ Failed to load config.yaml: {e}")
        sys.exit(1)


def check_paths(cfg):
    """Verify model paths exist and contain required files"""
    print("\n=== Checking Model Paths ===")
    
    # Check Whisper
    whisper_path = cfg.get("whisper_path", "")
    print(f"\nWhisper path: {whisper_path}")
    if os.path.isdir(whisper_path):
        files = os.listdir(whisper_path)
        print(f"  ✓ Directory exists ({len(files)} files)")
        required = ["config.json", "model.bin"]
        for req in required:
            exists = any(req in f for f in files)
            symbol = "✓" if exists else "✗"
            print(f"  {symbol} {req}: {exists}")
    else:
        print(f"  ✗ Directory does not exist!")
        return False
    
    # Check NLLB
    nllb_path = cfg.get("nllb_path", "")
    print(f"\nNLLB path: {nllb_path}")
    if os.path.isdir(nllb_path):
        files = os.listdir(nllb_path)
        print(f"  ✓ Directory exists ({len(files)} files)")
        required = ["config.json", "tokenizer_config.json"]
        model_files = [f for f in files if f.startswith("pytorch_model") or f.endswith(".bin")]
        
        for req in required:
            exists = req in files
            symbol = "✓" if exists else "✗"
            print(f"  {symbol} {req}: {exists}")
        
        if model_files:
            print(f"  ✓ Model files found: {model_files[:3]}")
        else:
            print(f"  ✗ No model weight files found!")
            return False
    else:
        print(f"  ✗ Directory does not exist!")
        return False
    
    return True


def check_gpu():
    """Check GPU availability and configuration"""
    print("\n=== Checking GPU ===")
    
    print(f"PyTorch version: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    
    if torch.cuda.is_available():
        print(f"CUDA version: {torch.version.cuda}")
        print(f"GPU count: {torch.cuda.device_count()}")
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            print(f"\nGPU {i}: {props.name}")
            print(f"  Memory: {props.total_memory / 1024**3:.2f} GB")
            print(f"  Compute capability: {props.major}.{props.minor}")
            
            # Check available memory
            torch.cuda.reset_peak_memory_stats(i)
            allocated = torch.cuda.memory_allocated(i) / 1024**3
            reserved = torch.cuda.memory_reserved(i) / 1024**3
            print(f"  Allocated: {allocated:.2f} GB")
            print(f"  Reserved: {reserved:.2f} GB")
        return True
    else:
        print("✗ No GPU available - will use CPU (SLOW)")
        return False


def test_translation(cfg):
    """Test actual translation pipeline"""
    print("\n=== Testing Translation Pipeline ===")
    
    try:
        from backend_offline import OfflineBackend
        
        print("Loading backend...")
        backend = OfflineBackend("config.yaml")
        print("✓ Backend loaded successfully")
        
        # Test ASR
        print("\nTesting ASR...")
        dummy_audio = np.zeros(16000, dtype=np.float32)  # 1 second silence
        asr_result = backend.asr(dummy_audio, "eng")
        print(f"ASR result: '{asr_result}' (empty is OK for silence)")
        
        # Test translation
        print("\nTesting translation...")
        test_text = "Hello world"
        print(f"Input: '{test_text}'")
        
        for tgt in ["hin", "sin", "vie", "nep"]:
            try:
                result = backend.translate(test_text, "eng", tgt)
                symbol = "✓" if result else "✗"
                print(f"  {symbol} eng → {tgt}: '{result}'")
                
                if not result:
                    print(f"    WARNING: Translation returned empty string!")
                    
            except Exception as e:
                print(f"  ✗ eng → {tgt}: ERROR - {e}")
                import traceback
                traceback.print_exc()
        
        return True
        
    except Exception as e:
        print(f"✗ Failed to load/test backend: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_dependencies():
    """Check if all required packages are installed"""
    print("\n=== Checking Dependencies ===")
    
    required = {
        "torch": "PyTorch",
        "numpy": "NumPy",
        "yaml": "PyYAML",
        "transformers": "Transformers",
        "faster_whisper": "Faster-Whisper",
        "sounddevice": "SoundDevice",
        "websockets": "WebSockets",
        "webrtcvad": "WebRTC VAD"
    }
    
    all_ok = True
    for pkg, name in required.items():
        try:
            __import__(pkg)
            print(f"✓ {name}")
        except ImportError:
            print(f"✗ {name} - NOT INSTALLED")
            all_ok = False
    
    return all_ok


def main():
    print("=" * 60)
    print("NirupanaX - System Diagnostic Tool")
    print("=" * 60)
    
    # Step 1: Check dependencies
    if not check_dependencies():
        print("\n⚠️  Some dependencies are missing. Install them first.")
        return
    
    # Step 2: Load config
    cfg = load_config()
    
    # Step 3: Check paths
    if not check_paths(cfg):
        print("\n⚠️  Model paths are invalid. Fix config.yaml")
        return
    
    # Step 4: Check GPU
    check_gpu()
    
    # Step 5: Test translation
    if not test_translation(cfg):
        print("\n⚠️  Translation test failed!")
        print("\nCommon fixes:")
        print("1. Ensure NLLB model files are complete")
        print("2. Try setting mt_threads: 1 in config.yaml")
        print("3. Check CUDA compatibility")
        print("4. Verify GPU has enough memory (need ~4GB)")
        return
    
    print("\n" + "=" * 60)
    print("✓ All checks passed! System should work.")
    print("=" * 60)


if __name__ == "__main__":
    main()