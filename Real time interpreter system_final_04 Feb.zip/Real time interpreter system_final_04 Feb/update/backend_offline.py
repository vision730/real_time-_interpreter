# backend_offline.py — OPTIMIZED FOR LOW LATENCY & ACCURACY
import os
from typing import Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
import yaml
import soundfile as sf
import time
from faster_whisper import WhisperModel
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM


def load_cfg(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


class OfflineBackend:
    def __init__(self, cfg_path: str = "config.yaml"):
        self.cfg = load_cfg(cfg_path)
        self.sr = int(self.cfg.get("sample_rate", 16000))
        
        self.device = "cuda" if (self.cfg.get("device", "cuda") == "cuda" and torch.cuda.is_available()) else "cpu"
        self.dtype = torch.float16 if self.device == "cuda" else torch.float32
        
        # Language barrier bypass switch
        self.bypass_language_barrier = bool(self.cfg.get("bypass_language_barrier", False))
        
        # Language configurations
        self.langs: Dict[str, Dict[str, str]] = self.cfg.get("languages", {})
        required = {"asr", "nllb"}
        for k, v in self.langs.items():
            if not isinstance(v, dict) or not required.issubset(v.keys()):
                raise ValueError(f"config.yaml languages['{k}'] missing {required - v.keys()}")
        
        # === ASR: Faster-Whisper ===
        wpath = self.cfg["whisper_path"]
        if not os.path.isdir(wpath):
            raise FileNotFoundError(f"Whisper path not found: {wpath}")
        
        compute_type = "float16" if self.device == "cuda" else "float32"
        
        # Optimized Whisper initialization
        self.whisper = WhisperModel(
            wpath,
            device=self.device,
            compute_type=compute_type,
            local_files_only=True,
            cpu_threads=6 if self.device == "cpu" else 0,  # Increased from 4
            num_workers=2,  # Increased from 1 for better throughput
        )
        print(f"[ASR] Loaded Faster-Whisper ({compute_type}) on {self.device}")
        
        # === MT: NLLB ===
        npath = self.cfg["nllb_path"]
        if not os.path.isdir(npath):
            raise FileNotFoundError(f"NLLB path not found: {npath}")
        
        # Thread-safe tokenizer (Python backend)
        mt_use_fast = bool(self.cfg.get("mt_use_fast", False))
        self.mt_tok = AutoTokenizer.from_pretrained(
            npath,
            local_files_only=True,
            use_fast=mt_use_fast,
        )
        
        self.mt_model = AutoModelForSeq2SeqLM.from_pretrained(
            npath,
            torch_dtype=self.dtype,
            local_files_only=True
        ).to(self.device)
        self.mt_model.eval()
        
        # Optimized MT parameters
        self.mt_max_new_tokens = int(self.cfg.get("mt_max_new_tokens", 96))
        
        # ASR guard configuration
        self.asr_guard = self.cfg.get("asr_guard", {})
        
        # NEW: Audio preprocessing parameters
        self.min_audio_rms = float(self.cfg.get("min_audio_rms", 0.005))
        self.max_audio_length = float(self.asr_guard.get("max_chunk_sec", 10.0))
        
        print(
            f"[OK] Backend ready on {self.device} | "
            f"bypass_language_barrier={self.bypass_language_barrier} | "
            f"mt_use_fast={mt_use_fast} | "
            f"mt_max_new_tokens={self.mt_max_new_tokens}"
        )
        
        # Warmup: Run a dummy inference to initialize GPU
        self._warmup()
    
    # ============ Internal Helpers ============
    
    def _codes(self, key: str):
        """Get ASR and NLLB language codes for a given key."""
        row = self.langs.get(key)
        if not row:
            raise ValueError(f"Unknown language key: {key}")
        return row["asr"], row["nllb"]
    
    def _save_asr_chunk(self, audio_f32: np.ndarray, src_key: str):
        """
        Save incoming ASR audio chunk as WAV.
        Folder structure:
            saved_chunks/<src_key>/chunk_<timestamp>.wav
        """
        # base folder by language
        out_dir = os.path.join("saved_chunks", src_key)
        os.makedirs(out_dir, exist_ok=True)

        # unique name using timestamp
        ts = int(time.time() * 1000)
        fname = f"chunk_{src_key}_{ts}.wav"
        path = os.path.join(out_dir, fname)

        # audio_f32 is float32 in [-1, 1]
        sf.write(path, audio_f32, self.sr)
        print(f"[ASR] Saved chunk: {path}")


    def _preprocess_audio(self, audio_f32: np.ndarray) -> Optional[np.ndarray]:
        """
        Preprocess audio: validate, truncate, and filter low-energy segments.
        Returns None if audio is invalid/silent.
        """
        if audio_f32.size == 0:
            return None
        
        # Truncate to max length
        max_len = int(self.max_audio_length * self.sr)
        if audio_f32.shape[0] > max_len:
            audio_f32 = audio_f32[:max_len].copy()
        
        # Check RMS energy (filter out silent audio)
        rms = np.sqrt(np.mean(audio_f32 ** 2))
        if rms < self.min_audio_rms:
            return None
        
        # Normalize audio to prevent clipping
        max_val = np.abs(audio_f32).max()
        if max_val > 0.95:
            audio_f32 = audio_f32 * (0.95 / max_val)
        
        return audio_f32
    
    def _pass_ascii_ratio(self, text: str) -> bool:
        """Check if text meets ASCII ratio requirements (for English guard)."""
        max_ratio = float(self.asr_guard.get("max_non_ascii_ratio", 0.50))
        if not text:
            return False
        non_ascii = sum(1 for c in text if ord(c) > 127)
        ratio = non_ascii / len(text)
        return ratio <= max_ratio
    
    # ============ ASR (Speech Recognition) ============
    
    @torch.inference_mode()
    def asr(self, audio_f32: np.ndarray, src_key: str) -> str:
        """
        Convert audio to text using Faster-Whisper.
        
        Optimizations:
        - Forced English for teacher (prevents misdetection)
        - No timestamps (faster decoding)
        - Greedy search (beam_size=1)
        - External VAD (vad_filter=False)
        """
        # Preprocess audio
        audio_f32 = self._preprocess_audio(audio_f32)
        if audio_f32 is None:
            return ""
        
        self._save_asr_chunk(audio_f32, src_key) #new
        
        asr_lang, _ = self._codes(src_key)
        
        # Force English for teacher to prevent misdetection as Tamil/Telugu/etc
        lang_param = "en" if src_key == "eng" else asr_lang
        
        try:
            segments, info = self.whisper.transcribe(
                audio_f32,
                language=lang_param,
                beam_size=1,  # Greedy (fastest)
                temperature=0.0,  # Deterministic
                vad_filter=False,  # External VAD already applied
                condition_on_previous_text=False,  # Prevent context errors
                task="transcribe",
                without_timestamps=True,  # 10-20ms faster
                # Optional: word_timestamps=False for even faster decoding
            )
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                print("[ASR] OOM detected - clearing cache")
                if self.device == "cuda":
                    torch.cuda.empty_cache()
                return ""
            raise
        
        # Language enforcement guard (English-only teacher)
        enforce = self.asr_guard.get("enforce_src_lang")
        if (not self.bypass_language_barrier
                and enforce
                and src_key == enforce
                and getattr(info, "language", "en") != "en"):
            print(f"[ASR] DROPPED: Detected {info.language} instead of English")
            return ""
        
        # Extract text from segments
        text = " ".join(seg.text for seg in segments).strip()
        
        # Truncate overly long text
        if len(text) > 250:
            text = text[:250] + "..."
            print(f"[ASR] Truncated long text ({len(text)} chars)")
        
        # Minimum length check
        min_len = int(self.asr_guard.get("min_text_len", 2))
        if len(text) < min_len:
            return ""
        
        # ASCII ratio guard (for English teacher)
        if (not self.bypass_language_barrier
                and self.asr_guard.get("enabled", True)
                and enforce
                and src_key == enforce):
            if not self._pass_ascii_ratio(text):
                print("[ASR] DROPPED: Failed ASCII ratio check")
                return ""
        
        if text.strip():
            print(f"[ASR_OUTPUT] ({src_key}) → {text}")
        return text
    
    # ============ Machine Translation ============
    
    @torch.inference_mode()
    def translate(self, text: str, src_key: str, tgt_key: str) -> str:
        """
        Translate text from src to tgt language using NLLB.
        
        Optimizations:
        - Reduced max_new_tokens (96 instead of 256)
        - Greedy search (num_beams=1)
        - No cache clearing (handled only on OOM)
        """
        if not text or len(text.strip()) == 0:
            return ""
        
        # Truncate input to prevent excessive computation
        if len(text) > 200:
            text = text[:200] + "..."
        
        _, src_nllb = self._codes(src_key)
        _, tgt_nllb = self._codes(tgt_key)
        
        # Set forced BOS token for target language
        forced_bos_token_id = None
        if hasattr(self.mt_tok, "lang_code_to_id"):
            self.mt_tok.src_lang = src_nllb
            # print(f"[MT] Setting source language to {src_nllb} and target language to {tgt_nllb}")
            forced_bos_token_id = self.mt_tok.lang_code_to_id.get(tgt_nllb, None)
        
        # Tokenize input
        tok = self.mt_tok(text, return_tensors="pt", padding=False).to(self.device)
        
        try:
            # Generate translation
            gen = self.mt_model.generate(
                **tok,
                max_new_tokens=self.mt_max_new_tokens,
                num_beams=1,  # Greedy (fastest)
                forced_bos_token_id=forced_bos_token_id,
                do_sample=False,  # Deterministic
         )
            
            # Decode output
            translation = self.mt_tok.batch_decode(gen, skip_special_tokens=True)[0].strip()
            return translation
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                print("[MT] OOM detected - clearing cache")
                if self.device == "cuda":
                    torch.cuda.empty_cache()
            return ""
    def _warmup(self):
        """Warmup GPU with dummy inference to reduce first-call latency."""
        print("[Warmup] Initializing GPU...")
        try:
            # Dummy audio (1 second of silence)
            dummy_audio = np.zeros(self.sr, dtype=np.float32)
            
            # Warmup ASR
            _ = self.asr(dummy_audio, "eng")
            
            # Warmup MT
            _ = self.translate("Hello", "eng", "hin")
            
            print("[Warmup] GPU ready - first inference will be faster")
        except Exception as e:
            print(f"[Warmup] Warning: {e}")
            
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                print("[MT] OOM detected - clearing cache")
                if self.device == "cuda":
                    torch.cuda.empty_cache()
            return ""
    
    # ============ Pipeline: Speech-to-Many (ASR + Multi-target MT) ============
    
    def s2many(self, audio_chunk_f32: np.ndarray, src_key: str, tgt_keys: List[str]) -> Dict:
        """
        Main pipeline: ASR + parallel translation to multiple target languages.
        
        Returns:
            {
              "_src_text": "recognized text",
              "_sr": 16000,
              "<tgt_key>": {
                  "tgt_text": "translated..."
              },
              ...
            }
        """
        # Step 1: Speech Recognition
        src_text = self.asr(audio_chunk_f32, src_key)
        
        result: Dict[str, dict] = {
            "_src_text": src_text,
            "_sr": self.sr
        }
        
        if not src_text or not tgt_keys:
            return result
        
        # Step 2: Parallel Translation
        # Remove duplicates while preserving order
        unique_tgts = list(dict.fromkeys(tgt_keys))
        
        def _translate_worker(tgt: str):
            """Worker function for parallel translation."""
            try:
                translated = self.translate(src_text, src_key, tgt)
                return tgt, translated
            except Exception as ex:
                print(f"[MT] Translation error for {tgt}: {ex}")
                return tgt, ""
        
        # Determine number of workers (max 4 for optimal GPU utilization)
        max_workers = min(
            len(unique_tgts),
            int(self.cfg.get("mt_threads", 4) or 1)
        )
        
        if max_workers <= 1:
            # Sequential processing (single target or forced single-thread)
            for tgt in unique_tgts:
                translated = self.translate(src_text, src_key, tgt)
                if translated:
                    result[tgt] = {"tgt_text": translated}
        else:
            # Parallel processing (multiple targets)
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(_translate_worker, tgt) for tgt in unique_tgts]
                
                for future in futures:
                    tgt, translated = future.result()
                    if translated:
                        result[tgt] = {"tgt_text": translated}
        
        return result