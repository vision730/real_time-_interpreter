import sys, os, asyncio, threading, queue, json, io, base64, wave, datetime
import numpy as np
import sounddevice as sd
import websockets

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QComboBox, QFileDialog, QMessageBox,
    QLineEdit, QCompleter
)
from PyQt5.QtCore import Qt, QTimer, QSettings
from PyQt5.QtGui import QPixmap, QPainter, QFont, QColor

# ============================================================
DOWN_QUEUE = queue.Queue()

LANG_MAP = {
    "English": "eng",
    "Hindi": "hin",
    "Sinhala": "sin",
    "Nepali": "nep",
    "Vietnamese": "vie",
    "Malayalam": "mal",
}
LANG_DISPLAY_LIST = list(LANG_MAP.keys())


def resource_path(relative_path: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


# ============================================================
# WS Worker (unchanged)
# ============================================================
async def ws_worker(uri: str, teacher_lang_code: str):
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(
                uri,
                ping_interval=30,
                ping_timeout=30,
                close_timeout=1,
                max_size=8 * 1024 * 1024,
                max_queue=None,
            ) as ws:
                await ws.send(json.dumps({
                    "type": "subscribe",
                    "tgt": teacher_lang_code,
                    "role": "teacher"
                }))
                async for msg in ws:
                    try:
                        data = json.loads(msg)
                    except Exception:
                        continue
                    if data.get("type") == "chunk" and data.get("dir") == "up":
                        DOWN_QUEUE.put(data)
        except asyncio.CancelledError:
            raise
        except Exception:
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 10.0)


# ============================================================
# Header Widget (same as student GUI)
# ============================================================
class HeaderWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(120)
        self.bg = QPixmap(resource_path("ban1.jpg"))
        self.left_logo = QPixmap(resource_path("mcte.png"))
        self.right_logo = QPixmap(resource_path("NX1.png"))

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        if not self.bg.isNull():
            p.drawPixmap(0, 0, self.width(), self.height(), self.bg)

        if not self.left_logo.isNull():
            p.drawPixmap(15, 20, self.left_logo.scaled(100, 80, Qt.KeepAspectRatio))
        if not self.right_logo.isNull():
            p.drawPixmap(self.width() - 115, 20, self.right_logo.scaled(100, 80, Qt.KeepAspectRatio))

        c = self.width() // 2
        f = QFont("Segoe UI Black", 34, QFont.Bold)
        p.setFont(f)
        fm = p.fontMetrics()
        sx = c - fm.width("NirūpanaX") // 2
        p.setPen(QColor("#49045C")); p.drawText(sx, 55, "N")
        p.setPen(QColor("#214F01")); p.drawText(sx + fm.width("N"), 55, "irūpana")
        p.setPen(QColor("#49045C")); p.drawText(sx + fm.width("Nirūpana"), 55, "X")
        p.setPen(QColor("#053F5B"))
        subf = QFont("Brush Script MT", 18, QFont.Normal, True)
        p.setFont(subf)
        sub = "One Classroom. Many Languages. Zero Barriers"
        p.drawText(c - p.fontMetrics().width(sub)//2, 95, sub)
        p.end()


# ============================================================
# Teacher Console Main Window
# ============================================================
class TeacherConsole(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Nirūpana – Teacher Console")
        self.resize(950, 700)
        self.connected = False
        self.uri = ""
        self.teacher_lang_code = "eng"
        self.history_text_store = []

        self.settings = QSettings("Nirupana", "TeacherConsole")
        self.saved_hosts = self.settings.value("saved_hosts", "").split(";") if self.settings.value("saved_hosts") else []

        self._build_ui()

        self.poll_timer = QTimer(self)
        self.poll_timer.timeout.connect(self.poll_downstream)
        self.poll_timer.start(80)

    # ============================================================
    def _build_ui(self):
        cw = QWidget(); self.setCentralWidget(cw)
        cw.setStyleSheet("background-color:#0f172a;")
        layout = QVBoxLayout(cw); layout.setContentsMargins(0,0,0,0)
        layout.addWidget(HeaderWidget())

        # Toolbar
        bar = QWidget(); bar.setStyleSheet("background-color:#1e40af;")
        bl = QHBoxLayout(bar); bl.setContentsMargins(10,6,10,6)
        bl.setSpacing(8)
        self.save_btn = QPushButton("Save Transcript")
        self.save_btn.setStyleSheet("""
            QPushButton {background:#475569;color:white;font-weight:bold;padding:6px 14px;border-radius:4px;}
            QPushButton:hover {background:#64748b;}
        """)
        self.save_btn.clicked.connect(self.save_transcript)
        bl.addWidget(self.save_btn)

        bl.addWidget(QLabel("<font color='white'>Server:</font>"))
        bl.addWidget(QLabel("<font color='white'>ws://</font>"))
        self.server_edit = QLineEdit("172.20.10.3:8765")
        self.server_edit.setFixedWidth(220)
        self.server_edit.setStyleSheet("QLineEdit{background:#1e293b;color:#f8fafc;padding:4px 6px;border:1px solid #334155;border-radius:4px;}")
        self.host_completer = QCompleter(self.saved_hosts)
        self.host_completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.server_edit.setCompleter(self.host_completer)
        bl.addWidget(self.server_edit)

        bl.addWidget(QLabel("<font color='white'>Teacher Lang:</font>"))
        self.lang_combo = QComboBox(); self.lang_combo.addItems(LANG_DISPLAY_LIST)
        self.lang_combo.setCurrentText("English")
        self.lang_combo.setStyleSheet("""
            QComboBox {
                background-color:#1e293b;
                color:#f1f5f9;
                border:1px solid #475569;
                border-radius:4px;
                padding:4px 6px;
                font-weight:500;
            }
            QComboBox:hover {
                border:1px solid #38bdf8;
            }
            QComboBox QAbstractItemView {
                background-color:#1e293b;
                color:#f8fafc;
                selection-background-color:#2563eb;
                selection-color:white;
            }
        """)
        bl.addWidget(self.lang_combo)

        self.connect_btn = QPushButton("Connect")
        self.connect_btn.setStyleSheet("QPushButton{background:#16a34a;color:white;font-weight:bold;padding:6px 12px;border-radius:4px;} QPushButton:hover{background:#22c55e;}")
        self.connect_btn.clicked.connect(self.connect_server)
        bl.addWidget(self.connect_btn)

        self.disconnect_btn = QPushButton("Disconnect")
        self.disconnect_btn.setStyleSheet("QPushButton{background:#dc2626;color:white;font-weight:bold;padding:6px 12px;border-radius:4px;} QPushButton:hover{background:#ef4444;}")
        self.disconnect_btn.clicked.connect(self.disconnect_server)
        bl.addWidget(self.disconnect_btn)
        layout.addWidget(bar)

        # Top: Translated output
        top = QWidget(); tl = QVBoxLayout(top); tl.setContentsMargins(10,10,10,5)
        tl.addWidget(QLabel("<font color='#cbd5f5'><b>Students → Teacher (Translated to your language):</b></font>"))
        self.latest_box = QTextEdit(); self.latest_box.setReadOnly(True)
        self.latest_box.setStyleSheet("background:#111827;color:#93c5fd;font-family:'Segoe UI';font-size:22px;font-weight:600;")
        tl.addWidget(self.latest_box)
        layout.addWidget(top,1)

        # Bottom: Transcript History
        bottom = QWidget(); blay = QVBoxLayout(bottom)
        blay.setContentsMargins(10,5,10,10); bottom.setStyleSheet("background:#1e293b;")
        blay.addWidget(QLabel("<font color='white'><b>Transcript History :</b></font>"))
        self.history_box = QTextEdit(); self.history_box.setReadOnly(True)
        self.history_box.setStyleSheet("background:#111827;color:#e2e8f0;font-family:'Segoe UI';font-size:20px;font-weight:500;")
        blay.addWidget(self.history_box,1)
        layout.addWidget(bottom,1)

    # ============================================================
    def connect_server(self):
        if self.connected: return
        host_part = self.server_edit.text().strip()
        if not host_part:
            QMessageBox.warning(self,"Server missing","Enter server host:port")
            return
        if host_part.startswith("ws://"):
            self.uri = host_part; normalized = host_part[5:]
        else:
            self.uri = "ws://" + host_part; normalized = host_part
        if normalized not in self.saved_hosts:
            self.saved_hosts.insert(0, normalized)
            self.settings.setValue("saved_hosts",";".join(self.saved_hosts))
            self.host_completer.model().setStringList(self.saved_hosts)
        lang_name = self.lang_combo.currentText()
        self.teacher_lang_code = LANG_MAP.get(lang_name,"eng")
        self.connected = True
        threading.Thread(target=lambda: asyncio.run(ws_worker(self.uri, self.teacher_lang_code)),daemon=True).start()
        self.connect_btn.setEnabled(False)
        self.disconnect_btn.setEnabled(True)

    def disconnect_server(self):
        if not self.connected: return
        self.connected = False
        self.connect_btn.setEnabled(True)
        self.disconnect_btn.setEnabled(False)

    # ============================================================
    def poll_downstream(self):
        try:
            while True:
                data = DOWN_QUEUE.get_nowait()
                self.handle_downstream(data)
        except queue.Empty:
            pass

    def handle_downstream(self, data: dict):
        src_text = data.get("src_text", "").strip()
        tgt_text = data.get("tgt_text", "").strip()
        ts = datetime.datetime.now().strftime("%H:%M:%S")

        # top field: translated only
        self.latest_box.setPlainText(tgt_text)

        block = (
            f"[{ts}] STUDENT: {src_text}\n"
            f"→ TO YOU ({data.get('tgt','')}): {tgt_text}\n\n"
        )
        self.history_text_store.append(block)

        html_block = (
            f"<span style='color:#d1d5db;'>[{ts}]</span> "
            f"<b><span style='color:#38bdf8;font-size:18px;'>STUDENT:</span></b> "
            f"<span style='color:#e2e8f0;font-size:18px;'>{src_text}</span><br>"
            f"<b><span style='color:#22c55e;font-size:22px;'>→ TO YOU ({data.get('tgt','')}):</span></b> "
            f"<span style='color:#93c5fd;font-size:22px;font-weight:600;'>{tgt_text}</span><br><br>"
        )

        self.history_box.moveCursor(self.history_box.textCursor().End)
        self.history_box.insertHtml(html_block)
        self.history_box.moveCursor(self.history_box.textCursor().End)

    # ============================================================
    def save_transcript(self):
        if not self.history_text_store:
            QMessageBox.information(self,"Save Transcript","No transcript yet.")
            return
        txt = "".join(self.history_text_store)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        default_name = f"teacher_transcript_{ts}.txt"
        path, _ = QFileDialog.getSaveFileName(self,"Save Transcript As…",default_name,"Text files (*.txt);;All files (*.*)")
        if path:
            with open(path,"w",encoding="utf-8") as f: f.write(txt)
            QMessageBox.information(self,"Saved",f"Transcript saved:\n{path}")


def main():
    app = QApplication(sys.argv)
    w = TeacherConsole()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
