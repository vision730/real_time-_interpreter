NirūpanaX – Offline Real-Time Classroom Interpreter
==================================================

One Classroom. Many Languages. Zero Barriers.

NirūpanaX is a 100% offline, GPU-accelerated, real-time speech-to-speech
interpreter designed for multilingual classrooms. It enables a teacher
to speak in English (or any chosen language) and instantly translates
the speech into Hindi, Nepali, Sinhala, Vietnamese, or any supported
language for connected student devices.

The system uses a LAN-based server–client architecture:

- Server Console (PyQt5) – runs ASR + MT + VAD + WebSockets
- Teacher GUI (PyQt5) – receives student questions
- Student GUI (PyQt5) – receives teacher translations

Works fully offline using Whisper (ASR), NLLB-200 (MT), and XTTS-v2 (optional TTS).


--------------------------------------------------
PROJECT STRUCTURE
--------------------------------------------------

NirupanaX/
│── main_server.py
│── server_ws_final.py
│── backend_offline.py
│── student_gui.py
│── teacher_gui.py
│── config.yaml
│── requirements.txt
│── models/
│     ├── asr/faster-whisper-medium/
│     ├── mt/nllb-200-distilled-600M/
│     └── tts/xtts_v2/ (optional)
│── assets/
      ├── ban1.jpg
      ├── mcte.png
      └── NX1.png


--------------------------------------------------
FEATURES
--------------------------------------------------

• Real-Time ASR (Faster-Whisper Medium)
• Offline translation using NLLB-200 Distilled 600M
• Custom VAD pipeline for clean segmentation
• PyQt5-based Server Console with logs, mic control, IP detection
• Teacher GUI with transcript history and student questions
• Student GUI with mic press-hold and translation output
• Complete LAN-based offline operation
• Supports multiple students simultaneously


--------------------------------------------------
MODELS + DOWNLOAD LINKS
--------------------------------------------------

1. ASR – Faster Whisper Medium (CT2)
   Download: https://huggingface.co/guillaumekln/faster-whisper-medium
   Path: models/asr/faster-whisper-medium/

2. MT – NLLB-200 Distilled 600M
   Download: https://huggingface.co/facebook/nllb-200-distilled-600M
   Path: models/mt/nllb-200-distilled-600M/

3. Optional TTS – XTTS-v2
   Download: https://huggingface.co/coqui/XTTS-v2
   Path: models/tts/xtts_v2/


--------------------------------------------------
INSTALLATION
--------------------------------------------------

1. Create Conda Environment
   conda create -n nirupana python=3.10 -y
   conda activate nirupana

2. Install Requirements
   pip install -r requirements.txt

GPU torch (if needed):
   pip install torch==2.5.1+cu121 torchaudio==2.5.1+cu121 -f https://download.pytorch.org/whl/cu121


--------------------------------------------------
CONFIGURATION (config.yaml)
--------------------------------------------------

ws_host: "0.0.0.0"
ws_port: 8765
sample_rate: 16000

teacher_lang: "eng"
allow_upstream: true

vad:
  bypass: false
  frame_ms: 20
  aggressiveness: 1
  min_voice_ms: 300
  max_silence_gap_ms: 700
  energy_gate: 0.005
  min_rms: 0.005
  min_duration_ms: 250
  speech_pad_ms: 200


--------------------------------------------------
RUNNING THE SERVER
--------------------------------------------------

Start Server Console:
   python main_server.py

Click:
• Start Server
• Mic On/Off
• Watch logs update live
• Check student connection count


--------------------------------------------------
RUNNING THE TEACHER GUI
--------------------------------------------------

   python teacher_gui.py

Steps:
1. Enter server IP: ws://<SERVER_IP>:8765
2. Select teacher language
3. Connect
4. Incoming student audio -> translated text shown instantly


--------------------------------------------------
RUNNING THE STUDENT GUI
--------------------------------------------------

   python student_gui.py

Steps:
1. Enter server IP
2. Select Speak Language + Receive Language
3. Hold "Ask" to speak
4. Translated text appears instantly
5. Transcript history saved as HTML


--------------------------------------------------
SYSTEM PIPELINE (SUMMARY)
--------------------------------------------------

Teacher speaking:
  Audio -> VAD -> Whisper ASR -> NLLB translation -> Student GUIs

Student speaking:
  Audio -> Base64 -> Server -> ASR -> Translation -> Teacher GUI

Average latency: 300–450 ms


--------------------------------------------------
TROUBLESHOOTING
--------------------------------------------------

• Missing first words:
  Increase speech_pad_ms to 200–250

• Hindi detected as English:
  Set teacher_lang to “eng”

• Students cannot connect:
  Use IP: ws://<SERVER_IP>:8765
  Disable firewall for port 8765

• Mic stuck on pause:
  Ensure no student is holding the mic button


--------------------------------------------------
CREDITS
--------------------------------------------------

Offline models:
• Faster-Whisper (OpenAI/CT2)
• NLLB-200 (Meta)

Frameworks:
• PyQt5
• NumPy
• WebSockets
• SoundDevice

Created for multilingual classroom support.


==================================================
END OF README
==================================================
