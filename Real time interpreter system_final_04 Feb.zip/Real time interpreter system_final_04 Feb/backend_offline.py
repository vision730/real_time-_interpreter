# backend_offline.py — OPTIMIZED FOR LOW LATENCY & ACCURACY + Vietnamese & Nepali Faster-Whisper ASR
import os
from typing import Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
import yaml
import soundfile as sf
import time
from faster_whisper import WhisperModel
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM


def load_cfg(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


class OfflineBackend:
    def __init__(self, cfg_path: str = "config.yaml"):
        self.cfg = load_cfg(cfg_path)
        self.sr = int(self.cfg.get("sample_rate", 16000))
        
        self.device = "cuda" if (self.cfg.get("device", "cuda") == "cuda" and torch.cuda.is_available()) else "cpu"
        self.dtype = torch.float16 if self.device == "cuda" else torch.float32
        
        # Language barrier bypass switch
        self.bypass_language_barrier = bool(self.cfg.get("bypass_language_barrier", False))
        
        # Language configurations
        self.langs: Dict[str, Dict[str, str]] = self.cfg.get("languages", {})
        required = {"asr", "nllb"}
        for k, v in self.langs.items():
            if not isinstance(v, dict) or not required.issubset(v.keys()):
                raise ValueError(f"config.yaml languages['{k}'] missing {required - v.keys()}")
        
        # === ASR: Faster-Whisper (Default) ===
        wpath = self.cfg["whisper_path"]
        if not os.path.isdir(wpath):
            raise FileNotFoundError(f"Whisper path not found: {wpath}")
        
        compute_type = "float16" if self.device == "cuda" else "float32"
        
        # Optimized Whisper initialization
        self.whisper = WhisperModel(
            wpath,
            device=self.device,
            compute_type=compute_type,
            local_files_only=True,
            cpu_threads=6 if self.device == "cpu" else 0,
            num_workers=2,
        )
        print(f"[ASR] Loaded Faster-Whisper ({compute_type}) on {self.device}")
        
        # === Vietnamese-specific Faster-Whisper ===
        vie_whisper_path = r"E:\fine_tune_whisper\whisper-faster-finetuned_med"
        self.vie_whisper = None
        if os.path.isdir(vie_whisper_path):
            self.vie_whisper = WhisperModel(
                vie_whisper_path,
                device=self.device,
                compute_type=compute_type,
                local_files_only=True,
                cpu_threads=6 if self.device == "cpu" else 0,
                num_workers=2,
            )
            print(f"[ASR] Loaded Vietnamese Faster-Whisper-small ({compute_type}) on {self.device}")
        else:
            print(f"[ASR] Vietnamese small model path not found: {vie_whisper_path}, will use default Whisper for 'vie'")
        
        # === Nepali-specific Faster-Whisper ===
        # Path chosen to match your screenshot / folder name
        nep_whisper_path = r"F:\Offline_Interpreter_system_NirupanaX\offline_interpreter\models\fast_whisper_nep"
        self.nep_whisper = None
        if os.path.isdir(nep_whisper_path):
            self.nep_whisper = WhisperModel(
                nep_whisper_path,
                device=self.device,
                compute_type=compute_type,
                local_files_only=True,
                cpu_threads=6 if self.device == "cpu" else 0,
                num_workers=2,
            )
            print(f"[ASR] Loaded Nepali Faster-Whisper ({compute_type}) on {self.device}")
        else:
            print(f"[ASR] Nepali model path not found: {nep_whisper_path}, using default Whisper for 'nep'")

        # === MT: NLLB ===
        npath = self.cfg["nllb_path"]
        if not os.path.isdir(npath):
            raise FileNotFoundError(f"NLLB path not found: {npath}")
        
        mt_use_fast = bool(self.cfg.get("mt_use_fast", False))
        self.mt_tok = AutoTokenizer.from_pretrained(npath, local_files_only=True, use_fast=mt_use_fast)
        self.mt_model = AutoModelForSeq2SeqLM.from_pretrained(npath, torch_dtype=self.dtype, local_files_only=True).to(self.device)
        self.mt_model.eval()
        
        self.mt_max_new_tokens = int(self.cfg.get("mt_max_new_tokens", 96))
        
        # ASR guard configuration
        self.asr_guard = self.cfg.get("asr_guard", {})
        
        # NEW: Audio preprocessing parameters
        self.min_audio_rms = float(self.cfg.get("min_audio_rms", 0.005))
        self.max_audio_length = float(self.asr_guard.get("max_chunk_sec", 10.0))
        
        print(
            f"[OK] Backend ready on {self.device} | "
            f"bypass_language_barrier={self.bypass_language_barrier} | "
            f"mt_use_fast={mt_use_fast} | "
            f"mt_max_new_tokens={self.mt_max_new_tokens}"
        )
        
        # Warmup: Run a dummy inference to initialize GPU
        self._warmup()
    
    # ============ Internal Helpers ============
    
    def _codes(self, key: str):
        row = self.langs.get(key)
        if not row:
            raise ValueError(f"Unknown language key: {key}")
        return row["asr"], row["nllb"]
    
    def _save_asr_chunk(self, audio_f32: np.ndarray, src_key: str):
        out_dir = os.path.join("saved_chunks", src_key)
        os.makedirs(out_dir, exist_ok=True)
        ts = int(time.time() * 1000)
        fname = f"chunk_{src_key}_{ts}.wav"
        path = os.path.join(out_dir, fname)
        sf.write(path, audio_f32, self.sr)
        print(f"[ASR] Saved chunk: {path}")
    
    def _preprocess_audio(self, audio_f32: np.ndarray) -> Optional[np.ndarray]:
        if audio_f32.size == 0:
            return None
        max_len = int(self.max_audio_length * self.sr)
        if audio_f32.shape[0] > max_len:
            audio_f32 = audio_f32[:max_len].copy()
        rms = np.sqrt(np.mean(audio_f32 ** 2))
        if rms < self.min_audio_rms:
            return None
        max_val = np.abs(audio_f32).max()
        if max_val > 0.95:
            audio_f32 = audio_f32 * (0.95 / max_val)
        return audio_f32
    
    def _pass_ascii_ratio(self, text: str) -> bool:
        max_ratio = float(self.asr_guard.get("max_non_ascii_ratio", 0.50))
        if not text:
            return False
        non_ascii = sum(1 for c in text if ord(c) > 127)
        ratio = non_ascii / len(text)
        return ratio <= max_ratio
    
    # ============ ASR (Speech Recognition) ============
    
    @torch.inference_mode()
    def asr(self, audio_f32: np.ndarray, src_key: str) -> str:
        audio_f32 = self._preprocess_audio(audio_f32)
        # if audio_f32 is None:
        #     return ""
        # self._save_asr_chunk(audio_f32, src_key)
        
        # Language-specific Faster-Whisper models
        if src_key == "vie" and self.vie_whisper is not None:
            return self.whisper_asr(audio_f32, src_key, model=self.vie_whisper)
        
        if src_key == "nep" and self.nep_whisper is not None:
            return self.whisper_asr(audio_f32, src_key, model=self.nep_whisper)
        
        # Otherwise use original Faster-Whisper
        return self.whisper_asr(audio_f32, src_key)
    
    @torch.inference_mode()
    def whisper_asr(self, audio_f32: np.ndarray, src_key: str, model=None) -> str:
        if model is None:
            model = self.whisper
        asr_lang, _ = self._codes(src_key)
        lang_param = "en" if src_key == "eng" else asr_lang
        try:
            segments, info = model.transcribe(
                audio_f32,
                language=lang_param,
                beam_size=1,
                temperature=0.0,
                vad_filter=False,
                condition_on_previous_text=False,
                task="transcribe",
                without_timestamps=True,
            )
        except RuntimeError as e:
            if "out of memory" in str(e).lower() and self.device == "cuda":
                torch.cuda.empty_cache()
                return ""
            raise
        text = " ".join(seg.text for seg in segments).strip()
        if len(text) > 250:
            text = text[:250] + "..."
        min_len = int(self.asr_guard.get("min_text_len", 2))
        if len(text) < min_len:
            return ""
        print(f"[ASR_OUTPUT] ({src_key}) → {text}")
        return text
    
    # ============ Machine Translation ============
    
    @torch.inference_mode()
    def translate(self, text: str, src_key: str, tgt_key: str) -> str:
        if not text or len(text.strip()) == 0:
            return ""
        if len(text) > 200:
            text = text[:200] + "..."
        _, src_nllb = self._codes(src_key)
        _, tgt_nllb = self._codes(tgt_key)
        forced_bos_token_id = None
        if hasattr(self.mt_tok, "lang_code_to_id"):
            self.mt_tok.src_lang = src_nllb
            forced_bos_token_id = self.mt_tok.lang_code_to_id.get(tgt_nllb, None)
        tok = self.mt_tok(text, return_tensors="pt", padding=False).to(self.device)
        try:
            gen = self.mt_model.generate(
                **tok,
                max_new_tokens=self.mt_max_new_tokens,
                num_beams=1,
                forced_bos_token_id=forced_bos_token_id,
                do_sample=False,
            )
            translation = self.mt_tok.batch_decode(gen, skip_special_tokens=True)[0].strip()
            return translation
        except RuntimeError as e:
            if "out of memory" in str(e).lower() and self.device == "cuda":
                torch.cuda.empty_cache()
            return ""
    
    # ============ Warmup ============
    
    def _warmup(self):
        print("[Warmup] Initializing GPU...")
        try:
            dummy_audio = np.zeros(self.sr, dtype=np.float32)
            _ = self.asr(dummy_audio, "eng")
            _ = self.translate("Hello", "eng", "hin")
            print("[Warmup] GPU ready - first inference will be faster")
        except Exception as e:
            print(f"[Warmup] Warning: {e}")
        except RuntimeError as e:
            if "out of memory" in str(e).lower() and self.device == "cuda":
                torch.cuda.empty_cache()
    
    # ============ Pipeline: Speech-to-Many ============
    
    def s2many(self, audio_chunk_f32: np.ndarray, src_key: str, tgt_keys: List[str]) -> Dict:
        src_text = self.asr(audio_chunk_f32, src_key)
        result: Dict[str, dict] = {"_src_text": src_text, "_sr": self.sr}
        if not src_text or not tgt_keys:
            return result
        unique_tgts = list(dict.fromkeys(tgt_keys))
        
        def _translate_worker(tgt: str):
            try:
                translated = self.translate(src_text, src_key, tgt)
                return tgt, translated
            except Exception as ex:
                print(f"[MT] Translation error for {tgt}: {ex}")
                return tgt, ""
        
        max_workers = min(len(unique_tgts), int(self.cfg.get("mt_threads", 4) or 1))
        if max_workers <= 1:
            for tgt in unique_tgts:
                translated = self.translate(src_text, src_key, tgt)
                if translated:
                    result[tgt] = {"tgt_text": translated}
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(_translate_worker, tgt) for tgt in unique_tgts]
                for future in futures:
                    tgt, translated = future.result()
                    if translated:
                        result[tgt] = {"tgt_text": translated}
        return result
