# server_ws_final.py — OPTIMIZED: FIFO SEGMENT QUEUE + FORCED SEGMENT SPLIT
import asyncio
import base64
import io
import json
import os
import queue
import signal
import sys
import threading
import time
import wave
from typing import Dict, Tuple, Optional

import numpy as np
import sounddevice as sd
import websockets
import webrtcvad
import yaml

from backend_offline import OfflineBackend

# ============ Global State ============
MIC_PAUSED = threading.Event()
CURRENT_SPEAKER: Dict[str, str] = {}

# ============ Configuration ============
def load_cfg(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


CFG = load_cfg("config.yaml")
WS_HOST = CFG.get("ws_host", "0.0.0.0")
WS_PORT = int(CFG.get("ws_port", 8765))
SAMPLE_RATE = int(CFG.get("sample_rate", 16000))
TEACHER_LANG = CFG.get("teacher_lang", "eng")
ALLOW_UPSTREAM = CFG.get("allow_upstream", True)

# VAD Configuration
VAD_CFG = CFG.get("vad", {})
BYPASS_VAD = bool(VAD_CFG.get("bypass", False))
FRAME_MS = int(VAD_CFG.get("frame_ms", 20))
VAD_AGGRESSIVENESS = int(VAD_CFG.get("aggressiveness", 1))
MIN_VOICE_MS = int(VAD_CFG.get("min_voice_ms", 300))
MAX_SILENCE_GAP_MS = int(VAD_CFG.get("max_silence_gap_ms", 700))
ENERGY_GATE = float(VAD_CFG.get("energy_gate", 0.005))
SEG_MIN_RMS = float(VAD_CFG.get("min_rms", 0.005))
SEG_MIN_DURATION_MS = int(VAD_CFG.get("min_duration_ms", 250))
MAX_SEGMENT_MS = int(VAD_CFG.get("max_segment_ms", 5000))  # NEW: hard limit per segment

# Audio padding
SPEECH_PAD_MS = 200
RAW_CHUNK_MS = 1200


# ============ Audio Utilities ============
def _resample_np(x: np.ndarray, sr_from: int, sr_to: int) -> np.ndarray:
    """Fast linear interpolation resampling."""
    if sr_from == sr_to or x.size == 0:
        return x.astype(np.float32)

    ratio = sr_to / float(sr_from)
    n_out = int(round(x.size * ratio))

    xp = np.linspace(0.0, 1.0, num=x.size, endpoint=False, dtype=np.float64)
    xq = np.linspace(0.0, 1.0, num=n_out, endpoint=False, dtype=np.float64)
    y = np.interp(xq, xp, x.astype(np.float32))

    return y.astype(np.float32)


def _apply_audio_backend_from_config():
    """Select the best available input device."""
    try:
        default_in, _ = sd.default.device
        if default_in is not None and default_in >= 0:
            info = sd.query_devices(default_in)
            print(f"[Mic] Using system default: {info['name']}")
            return default_in
    except Exception as e:
        print(f"[Mic] Default device error: {e}")

    dev = CFG.get("input_device", None)
    if dev is not None:
        try:
            info = sd.query_devices(dev)
            if info.get("max_input_channels", 0) > 0:
                print(f"[Mic] Using configured device {dev}: {info['name']}")
                return dev
        except Exception as e:
            print(f"[Mic] Configured device {dev} invalid: {e}")

    return None


def _pick_input_samplerate(device_index, preferred=None):
    try:
        devinfo = (
            sd.query_devices(device_index)
            if device_index is not None
            else sd.query_devices(None, "input")
        )
    except Exception:
        devinfo = {}

    candidates = []
    if preferred:
        candidates.append(int(preferred))
    if "default_samplerate" in devinfo:
        candidates.append(int(round(devinfo["default_samplerate"])))
    candidates += [48000, 16000]

    for sr in candidates:
        try:
            sd.check_input_settings(
                device=device_index, samplerate=sr, channels=1, dtype="float32"
            )
            print(f"[Mic] Using sample rate: {sr} Hz")
            return sr
        except Exception:
            continue

    raise RuntimeError("No valid sample rate found")


def decode_wav_b64_to_float32(b64: str) -> Tuple[np.ndarray, int]:
    raw = base64.b64decode(b64)
    with wave.open(io.BytesIO(raw), "rb") as wf:
        sr = wf.getframerate()
        n = wf.getnframes()
        pcm = wf.readframes(n)
        ch = wf.getnchannels()
        sw = wf.getsampwidth()

    if sw != 2:
        raise RuntimeError("Expected 16-bit PCM WAV")

    audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32767.0

    if ch > 1:
        audio = audio.reshape(-1, ch)[:, 0]

    return audio, sr


# ============ VAD Microphone Stream ============
class MicVADStream:
    def __init__(self, sample_rate: int):
        self.sr = int(sample_rate)
        self.frame_ms = FRAME_MS
        self.frame_len = int(self.sr * self.frame_ms / 1000)
        self.vad = webrtcvad.Vad(VAD_AGGRESSIVENESS)
        self.energy_gate = ENERGY_GATE
        self.min_frames = max(1, int(MIN_VOICE_MS / self.frame_ms))
        self.max_gap_frames = max(1, int(MAX_SILENCE_GAP_MS / self.frame_ms))
        self.max_segment_frames = max(1, int(MAX_SEGMENT_MS / self.frame_ms))  # NEW

        # Padding frames to capture word boundaries
        self.pad_frames = max(1, int(SPEECH_PAD_MS / self.frame_ms))

        self._q = queue.Queue(maxsize=100)
        self._stop = threading.Event()
        self._stream = None
        self._buf = bytearray()
        self._frame_bytes = self.frame_len * 2

        # Ring buffer for pre-padding
        self._ring_buffer = []
        self._ring_buffer_size = self.pad_frames

    def _callback(self, indata, frames, time_info, status):
        if status:
            return

        x = np.clip(indata[:, 0], -1.0, 1.0)
        pcm16 = (x * 32767.0).astype(np.int16).tobytes()

        try:
            self._q.put(pcm16, block=False)
        except queue.Full:
            # Drop oldest frame if queue is full
            try:
                self._q.get_nowait()
                self._q.put(pcm16, block=False)
            except Exception:
                pass

    def _open_stream(self):
        """Open audio input stream."""
        device_index = _apply_audio_backend_from_config()
        self._stream = sd.InputStream(
            samplerate=self.sr,
            channels=1,
            dtype="float32",
            blocksize=self.frame_len,
            callback=self._callback,
            device=device_index,
        )
        self._stream.start()
        print(f"[Mic] Stream started @ {self.sr} Hz")
        return device_index

    def __enter__(self):
        try:
            self._open_stream()
        except Exception as e:
            print(f"[Mic] Failed to open stream: {e}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._stop.set()
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
        print("[Mic] Stream stopped")

    def segments(self):
        voiced_frames = []
        voiced_count = 0
        gap_count = 0

        while not self._stop.is_set():
            # Pause handling
            while MIC_PAUSED.is_set():
                time.sleep(0.05)
                self._ring_buffer.clear()

            # Ensure stream is active
            if self._stream is None or not self._stream.active:
                try:
                    self._open_stream()
                except Exception:
                    time.sleep(1.0)
                    continue

            # Get audio chunk from queue
            try:
                chunk = self._q.get(timeout=0.5)
            except queue.Empty:
                continue

            self._buf.extend(chunk)

            def vad_ok(frame_bytes: bytes) -> bool:
                """Check if frame contains speech."""
                # Energy-based pre-filter
                if self.energy_gate > 0.0:
                    f = (
                        np.frombuffer(frame_bytes, dtype=np.int16)
                        .astype(np.float32)
                        / 32767.0
                    )
                    if np.abs(f).mean() < self.energy_gate:
                        return False

                # WebRTC VAD
                try:
                    return self.vad.is_speech(frame_bytes, self.sr)
                except Exception:
                    return False

            # Process frames
            while len(self._buf) >= self._frame_bytes:
                frame = bytes(self._buf[: self._frame_bytes])
                del self._buf[: self._frame_bytes]

                # Maintain ring buffer for pre-padding
                self._ring_buffer.append(frame)
                if len(self._ring_buffer) > self._ring_buffer_size:
                    self._ring_buffer.pop(0)

                if vad_ok(frame):
                    # Speech detected
                    if voiced_count == 0:
                        # Start of new speech segment - add pre-padding
                        voiced_frames.extend(self._ring_buffer[:-1])

                    voiced_frames.append(frame)
                    voiced_count += 1
                    gap_count = 0

                    # NEW: if continuous speech too long, force-cut a segment
                    if voiced_count >= self.max_segment_frames:
                        pcm = b"".join(voiced_frames)
                        audio = (
                            np.frombuffer(pcm, dtype=np.int16)
                            .astype(np.float32)
                            / 32767.0
                        )
                        dur_ms = voiced_count * self.frame_ms
                        rms = np.sqrt(np.mean(audio ** 2))

                        if dur_ms >= SEG_MIN_DURATION_MS and rms >= SEG_MIN_RMS:
                            print(f"[VAD] Forced segment: {dur_ms:.0f}ms, RMS: {rms:.4f}")
                            yield audio

                        # reset for next segment while teacher still speaking
                        voiced_frames.clear()
                        voiced_count = 0
                        gap_count = 0
                        self._ring_buffer.clear()

                else:
                    # Silence detected
                    if voiced_count > 0:
                        voiced_frames.append(frame)
                        gap_count += 1

                        if gap_count > self.max_gap_frames:
                            # End of speech segment
                            if voiced_count >= self.min_frames:
                                # Convert to audio array
                                pcm = b"".join(voiced_frames)
                                audio = (
                                    np.frombuffer(pcm, dtype=np.int16)
                                    .astype(np.float32)
                                    / 32767.0
                                )

                                # Quality checks
                                dur_ms = voiced_count * self.frame_ms
                                rms = np.sqrt(np.mean(audio**2))

                                if dur_ms >= SEG_MIN_DURATION_MS and rms >= SEG_MIN_RMS:
                                    print(
                                        f"[VAD] Segment: {dur_ms:.0f}ms, RMS: {rms:.4f}"
                                    )
                                    yield audio

                            # Reset for next segment
                            voiced_frames.clear()
                            voiced_count = gap_count = 0


# ============ WebSocket Server ============
class TeacherServer:
    def __init__(self):
        self.backend = OfflineBackend("config.yaml")
        self.clients: Dict[websockets.WebSocketServerProtocol, dict] = {}
        self.lock = asyncio.Lock()
        self.out_q: asyncio.Queue = asyncio.Queue(maxsize=500)  # outbound JSON
        # FIFO queue for teacher audio segments
        self.seg_q: queue.Queue = queue.Queue(maxsize=200)
        self.seg_worker: Optional[threading.Thread] = None

    async def _broadcaster(self):
        """Background task to broadcast messages to clients."""
        while True:
            ws, payload = await self.out_q.get()
            try:
                await ws.send(json.dumps(payload))
            except Exception:
                # Remove disconnected clients
                async with self.lock:
                    self.clients.pop(ws, None)

    async def register(self, ws, tgt_key: str, role: str = "student", src: str = "eng"):
        async with self.lock:
            self.clients[ws] = {"tgt": tgt_key, "role": role, "src": src}
        print(
            f"[WS] + {role} client {ws.remote_address} (src={src}, tgt={tgt_key}). Total={len(self.clients)}"
        )

    async def unregister(self, ws):
        async with self.lock:
            was_present = ws in self.clients
            self.clients.pop(ws, None)
        if was_present:
            print(f"[WS] - client {ws.remote_address}. Total={len(self.clients)}")

    async def _snapshot_clients(self):
        async with self.lock:
            return dict(self.clients)

    async def _broadcast_pause_to_students(self, state: bool):
        snap = await self._snapshot_clients()
        payload = {"type": "pause_mic", "state": state}
        sent = 0

        for ws, info in snap.items():
            if info.get("role") == "student":
                try:
                    await ws.send(json.dumps(payload))
                    sent += 1
                except Exception:
                    pass

        action = "PAUSE" if state else "RESUME"
        print(f"[CTRL] {action} broadcast to {sent} student(s)")

    async def handler(self, ws):
        try:
            # Wait for subscription message
            msg = await asyncio.wait_for(ws.recv(), timeout=10)
            data = json.loads(msg)

            if not (isinstance(data, dict) and data.get("type") == "subscribe"):
                await ws.send(
                    json.dumps(
                        {
                            "type": "error",
                            "message": "Send subscribe with src/tgt/role",
                        }
                    )
                )
                return

            role = data.get("role", "student")
            tgt = data.get("tgt")
            src = data.get("src", tgt if role == "student" else CFG.get("default_src", "eng"))

            if not tgt:
                await ws.send(
                    json.dumps(
                        {
                            "type": "error",
                            "message": "tgt (target language) required",
                        }
                    )
                )
                return

            await self.register(ws, tgt, role, src)

            # Send welcome message
            await ws.send(
                json.dumps(
                    {
                        "type": "chunk",
                        "dir": "down" if role == "student" else "up",
                        "sr": SAMPLE_RATE,
                        "src_text": "(connection established)",
                        "tgt": tgt,
                        "tgt_text": f"Connected: {tgt} ({role})",
                        "wav_b64": "",
                        "proc_ms": 0,
                    }
                )
            )

            # Handle incoming messages
            async for msg in ws:
                try:
                    data = json.loads(msg)
                except Exception:
                    continue

                typ = data.get("type")

                # Handle pause/resume commands
                if typ == "pause_mic":
                    ws_id = f"{ws.remote_address[0]}:{ws.remote_address[1]}"
                    new_state = bool(data.get("state", False))

                    if new_state:
                        # Student starts speaking
                        MIC_PAUSED.set()
                        CURRENT_SPEAKER[ws_id] = src
                        print(
                            f"[CTRL] Student {ws_id} speaking (src={src}) - pausing teacher mic"
                        )
                        await self._broadcast_pause_to_students(True)
                    else:
                        # Student stops speaking
                        MIC_PAUSED.clear()
                        CURRENT_SPEAKER.pop(ws_id, None)
                        print(
                            f"[CTRL] Student {ws_id} stopped - resuming teacher mic"
                        )
                        await self._broadcast_pause_to_students(False)
                    continue

                # Handle upstream audio from students
                if typ == "up_chunk" and ALLOW_UPSTREAM:
                    wav_b64 = data.get("wav_b64", "")
                    src_key = data.get("src", src)
                    if not wav_b64:
                        continue

                    try:
                        audio, sr = decode_wav_b64_to_float32(wav_b64)
                        if sr != SAMPLE_RATE:
                            audio = _resample_np(audio, sr, SAMPLE_RATE)
                        asyncio.create_task(self._handle_upstream(audio, src_key))
                    except Exception as e:
                        print(f"[UP] Parse error: {e}")
                    continue

        except Exception as e:
            print(f"[WS] Handler exception: {e}")
        finally:
            await self.unregister(ws)

    async def _handle_upstream(self, audio_f32: np.ndarray, src_key: str):
        """Process upstream audio from students (translate to teacher language)."""
        try:
            out = await asyncio.to_thread(
                self.backend.s2many, audio_f32, src_key, [TEACHER_LANG]
            )
        except Exception as e:
            print(f"[UP] Backend error: {e}")
            return

        cell = out.get(TEACHER_LANG) or {}
        payload = {
            "type": "chunk",
            "dir": "up",
            "sr": out.get("_sr", SAMPLE_RATE),
            "src_text": out.get("_src_text", ""),
            "tgt": TEACHER_LANG,
            "tgt_text": cell.get("tgt_text", ""),
            "wav_b64": "",
            "proc_ms": 0,
        }

        # Send to teacher clients
        snap = await self._snapshot_clients()
        sent = 0
        for ws, info in snap.items():
            if info.get("role") == "teacher":
                try:
                    await ws.send(json.dumps(payload))
                    sent += 1
                except Exception:
                    pass

        if sent > 0:
            print(f"[UP] Delivered to {sent} teacher client(s)")

    def run(self):
        """Start the WebSocket server (CLI mode)."""
        loop = asyncio.get_event_loop()

        async def serve():
            async with websockets.serve(
                self.handler,
                WS_HOST,
                WS_PORT,
                ping_interval=20,
                ping_timeout=20,
                max_size=8 * 1024 * 1024,
            ):
                print(f"[WS] Server listening on ws://{WS_HOST}:{WS_PORT}")
                asyncio.create_task(self._broadcaster())

                # Start microphone + segment worker threads
                mic_thread = threading.Thread(
                    target=self._mic_loop,
                    args=(loop,),
                    daemon=True,
                )
                mic_thread.start()

                await asyncio.Future()  # Run forever

        loop.run_until_complete(serve())

    # ========== Segment worker ==========
    def _segment_worker(self, loop: asyncio.AbstractEventLoop):
        """Background worker: consume audio segments FIFO and run backend translation."""
        src_key = CFG.get("teacher_lang", "eng")

        print("[PIPELINE] Segment worker started")
        while True:
            item = self.seg_q.get()
            if item is None:
                print("[PIPELINE] Segment worker shutting down")
                break

            segment, targets = item
            if not isinstance(targets, set):
                targets = set(targets)

            if not targets:
                continue

            # Run ASR + translation
            t0 = time.time()
            try:
                out = self.backend.s2many(segment, src_key, list(targets))
            except Exception as e:
                print(f"[ERR] Backend error (worker): {e}")
                continue
            dt = time.time() - t0

            if not out.get("_src_text"):
                continue

            # Logging preview
            tgt_sample = next(iter(targets)) if targets else None
            if tgt_sample:
                src_preview = out.get("_src_text", "")[:50]
                tgt_preview = out.get(tgt_sample, {}).get("tgt_text", "")[:50]
                latency_ms = int(dt * 1000)
                if latency_ms < 500:
                    status = "✓ FAST"
                elif latency_ms < 800:
                    status = "✓ GOOD"
                else:
                    status = "⚠ SLOW"
                print(
                    f"[PIPELINE] {status} {latency_ms}ms | {len(targets)} langs | "
                    f"'{src_preview}' → '{tgt_preview}'"
                )

            # Fresh snapshot at send-time
            try:
                fut = asyncio.run_coroutine_threadsafe(
                    self._snapshot_clients(), loop
                )
                clients_snapshot = fut.result(timeout=1.0)
            except Exception as e:
                print(f"[PIPELINE] snapshot error: {e}")
                continue

            sent = 0
            for ws, info in clients_snapshot.items():
                tgt_key = info.get("tgt")
                role = info.get("role", "student")

                if role != "student":
                    continue
                if tgt_key not in targets:
                    continue

                cell = out.get(tgt_key)
                if not cell:
                    continue

                payload = {
                    "type": "chunk",
                    "dir": "down",
                    "sr": out.get("_sr", SAMPLE_RATE),
                    "src_text": out.get("_src_text", ""),
                    "tgt": tgt_key,
                    "tgt_text": cell.get("tgt_text", ""),
                    "wav_b64": "",
                    "proc_ms": int(dt * 1000),
                }

                try:
                    loop.call_soon_threadsafe(
                        self.out_q.put_nowait, (ws, payload)
                    )
                    sent += 1
                except asyncio.QueueFull:
                    print("[PIPELINE] out_q full; dropping payload")

            if sent > 0:
                print(f"[PIPELINE] Enqueued to {sent} student(s)")

    # ========== Mic loop ==========
    def _mic_loop(self, loop: asyncio.AbstractEventLoop):
        # Start translation worker once
        if self.seg_worker is None:
            self.seg_worker = threading.Thread(
                target=self._segment_worker,
                args=(loop,),
                daemon=True,
            )
            self.seg_worker.start()

        if BYPASS_VAD:
            # Bypass mode: continuous capture without VAD
            print("[Mic] Running in BYPASS mode (no VAD)")
            while True:
                device_index = _apply_audio_backend_from_config()
                cfg_pref_sr = CFG.get("input_samplerate", None)

                try:
                    in_sr = _pick_input_samplerate(device_index, preferred=cfg_pref_sr)
                    block = int(in_sr * RAW_CHUNK_MS / 1000)

                    with sd.InputStream(
                        samplerate=in_sr,
                        channels=1,
                        dtype="float32",
                        blocksize=block,
                        device=device_index,
                    ) as stream:
                        while True:
                            # Wait while paused
                            while MIC_PAUSED.is_set():
                                time.sleep(0.05)

                            frames, _ = stream.read(block)
                            segment = frames[:, 0].copy().astype(np.float32)

                            if in_sr != SAMPLE_RATE:
                                segment = _resample_np(segment, in_sr, SAMPLE_RATE)

                            self._process_segment(loop, segment)

                except Exception as e:
                    print(f"[Mic] BYPASS error: {e}. Retrying...")
                    time.sleep(1.0)

        else:
            print("[Mic] Running in VAD mode")
            while True:
                in_sr_vad = None
                device_index = _apply_audio_backend_from_config()
                for sr_try in (48000, 16000):
                    try:
                        sd.check_input_settings(
                            device=device_index,
                            samplerate=sr_try,
                            channels=1,
                            dtype="float32",
                        )
                        in_sr_vad = sr_try
                        break
                    except Exception:
                        continue

                if in_sr_vad is None:
                    print("[VAD] No valid sample rate found, retrying...")
                    time.sleep(1.0)
                    continue

                try:
                    with MicVADStream(sample_rate=in_sr_vad) as mic:
                        for segment in mic.segments():
                            # Resample if needed
                            if in_sr_vad != SAMPLE_RATE:
                                segment = _resample_np(
                                    segment, in_sr_vad, SAMPLE_RATE
                                )

                            self._process_segment(loop, segment)

                except Exception as e:
                    print(f"[VAD] Error: {e}. Reopening stream...")
                    time.sleep(1.0)

    def _process_segment(self, loop: asyncio.AbstractEventLoop, segment: np.ndarray):
        """Validate audio and enqueue it for the FIFO worker (no heavy work here)."""
        if segment.size == 0:
            return

        rms = np.sqrt(np.mean(segment**2))
        if rms < SEG_MIN_RMS:
            return

        # Check current clients
        try:
            fut = asyncio.run_coroutine_threadsafe(
                self._snapshot_clients(), loop
            )
            clients_snapshot = fut.result(timeout=0.5)
        except Exception:
            clients_snapshot = {}

        # Determine target languages
        targets = {
            info.get("tgt")
            for info in clients_snapshot.values()
            if info.get("role") == "student"
        }
        targets.discard(None)

        if not targets:
            return

        # If a student is speaking, skip teacher mic segments
        if CURRENT_SPEAKER:
            speaker_id = list(CURRENT_SPEAKER.keys())[0]
            speaking_src = CURRENT_SPEAKER[speaker_id]
            print(
                f"[PIPELINE] Student speaking (src={speaking_src}) - skipping teacher chunk"
            )
            return

        # Enqueue segment for worker in FIFO order
        try:
            self.seg_q.put((segment, targets), timeout=1.0)
        except queue.Full:
            # Block until space is available to avoid dropping audio
            print(
                "[PIPELINE] seg_q full; waiting to enqueue to avoid dropping audio..."
            )
            self.seg_q.put((segment, targets))

        # (No direct backend call here — worker will process in order)


# ============ Main Entry Point ============
if __name__ == "__main__":
    def _sigint(_sig, _frm):
        print("\n[WS] Shutting down gracefully...")
        sys.exit(0)

    signal.signal(signal.SIGINT, _sigint)

    print("=" * 60)
    print("REAL-TIME INTERPRETER SERVER (OPTIMIZED + FIFO QUEUE + MAX SEGMENT)")
    print("=" * 60)

    TeacherServer().run()
