import sys, os, asyncio, threading, queue, json, io, base64, wave, datetime
import numpy as np
import sounddevice as sd
import websockets

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QComboBox, QFileDialog, QMessageBox,
    QLineEdit
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap, QPainter, QFont, QColor

# ============================================================
# Queues – WebSocket ↔ GUI
# ============================================================
DOWN_QUEUE = queue.Queue()
UP_QUEUE = queue.Queue()

LANG_MAP = {
    "English": "eng",
    "Hindi": "hin",
    "Sinhala": "sin",
    "Nepali": "nep",
    "Vietnamese": "vie",
    "Malayalam": "mal",
}
LANG_DISPLAY_LIST = list(LANG_MAP.keys())


def lang_to_code(name: str) -> str:
    return LANG_MAP.get(name, name)


def resource_path(relative_path: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


def wav_b64_from_f32(f32: np.ndarray, sr: int = 16000) -> str:
    i16 = np.clip(f32 * 32767, -32768, 32767).astype(np.int16).tobytes()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(i16)
    return base64.b64encode(buf.getvalue()).decode("ascii")


# WebSocket workers
async def ws_downstream(uri: str, tgt_code: str):
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(
                uri,
                ping_interval=30,
                ping_timeout=30,
                close_timeout=1,
                max_size=8 * 1024 * 1024,
                max_queue=None,
            ) as ws:
                await ws.send(
                    json.dumps({"type": "subscribe", "tgt": tgt_code, "role": "student"})
                )
                backoff = 1.0
                async for msg in ws:
                    try:
                        data = json.loads(msg)
                    except Exception:
                        continue
                    if data.get("type") == "chunk" and data.get("dir") == "down":
                        DOWN_QUEUE.put(data)
        except asyncio.CancelledError:
            raise
        except Exception:
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 10.0)


async def ws_upstream(uri: str, src_code: str):
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(
                uri,
                ping_interval=30,
                ping_timeout=30,
                close_timeout=1,
                max_size=8 * 1024 * 1024,
                max_queue=None,
            ) as ws:
                await ws.send(
                    json.dumps({"type": "subscribe", "tgt": src_code, "role": "student"})
                )
                backoff = 1.0
                loop = asyncio.get_event_loop()
                while True:
                    payload = await loop.run_in_executor(None, UP_QUEUE.get)
                    if isinstance(payload, dict) and payload.get("type") in (
                        "pause_mic",
                        "up_chunk",
                    ):
                        await ws.send(json.dumps(payload))
        except asyncio.CancelledError:
            raise
        except Exception:
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 10.0)


# Header widget 
class HeaderWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(120)
        bg_path = resource_path("ban1.jpg")
        self.bg = QPixmap(bg_path) if os.path.exists(bg_path) else None
        self.left_logo = QPixmap(resource_path("mcte.png"))
        self.right_logo = QPixmap(resource_path("NX1.png"))

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)

        if self.bg and not self.bg.isNull():
            p.drawPixmap(0, 0, self.width(), self.height(), self.bg)
        else:
            p.fillRect(self.rect(), Qt.darkRed)

        if not self.left_logo.isNull():
            p.drawPixmap(
                15,
                20,
                self.left_logo.scaled(100, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation),
            )
        if not self.right_logo.isNull():
            p.drawPixmap(
                self.width() - 115,
                20,
                self.right_logo.scaled(100, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation),
            )

        centre_x = self.width() // 2
        title_font = QFont("Segoe UI Black", 34, QFont.Bold)
        p.setFont(title_font)
        fm = p.fontMetrics()
        start_x = centre_x - fm.width("NirūpanaX") // 2

        p.setPen(QColor("#49045C"))
        p.drawText(start_x, 55, "N")
        p.setPen(QColor("#214F01"))
        p.drawText(start_x + fm.width("N"), 55, "irūpana")
        p.setPen(QColor("#49045C"))
        p.drawText(start_x + fm.width("Nirūpana"), 55, "X")

        sub = "One Classroom. Many Languages. Zero Barriers"
        p.setPen(QColor("#053F5B"))
        sub_font = QFont("Brush Script MT", 18)
        sub_font.setItalic(True)
        p.setFont(sub_font)
        p.drawText(
            centre_x - p.fontMetrics().width(sub) // 2,
            95,
            sub,
        )
        p.end()


# Main Window
class StudentConsole(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Nirūpana – Student Console")
        self.resize(950, 750)

        self.connected = False
        self.uri = ""
        self.rec_sr = 16000
        self.rec_frames = []
        self.rec_stream = None
        self.energy_gate = 0.01

        self._build_ui()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll)
        self.timer.start(80)

    # --------------------------------------------------------
    def _build_ui(self):
        cw = QWidget()
        self.setCentralWidget(cw)
        cw.setStyleSheet("background-color:#0f172a;")

        layout = QVBoxLayout(cw)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(HeaderWidget())

        # ---------- Toolbar ----------
        bar = QWidget()
        bar.setStyleSheet("background-color:#1e3a8a;")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(10, 6, 10, 6)
        bl.setSpacing(8)

        self.ask_btn = QPushButton("Ask (press  hold)")
        self.ask_btn.setEnabled(False)
        self.ask_btn.setStyleSheet(
            """
            QPushButton {
                background:#0a2256;
                color:white;
                font-weight:bold;
                padding:6px 14px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#1e40af;
            }
        """
        )
        self.ask_btn.pressed.connect(self._on_press)
        self.ask_btn.released.connect(self._on_release)
        bl.addWidget(self.ask_btn)

        save_btn = QPushButton("Save Transcript")
        save_btn.setStyleSheet(
            """
            QPushButton {
                background:#475569;
                color:white;
                font-weight:bold;
                padding:6px 14px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#64748b;
            }
        """
        )
        save_btn.clicked.connect(self.save_transcript)
        bl.addWidget(save_btn)

        bl.addSpacing(20)
        bl.addWidget(QLabel("<font color='white'>Server:</font>"))
        bl.addWidget(QLabel("<font color='white'>ws://</font>"))

        self.server = QLineEdit("192.168.1.46:8765")
        self.server.setFixedWidth(220)
        self.server.setStyleSheet(
            """
            QLineEdit {
                background:#1e293b;
                color:#f8fafc;
                padding:4px 6px;
                border:1px solid #334155;
                border-radius:4px;
            }
        """
        )
        bl.addWidget(self.server)

        bl.addStretch()

        connect_btn = QPushButton("Connect")
        connect_btn.setStyleSheet(
            """
            QPushButton {
                background:#16a34a;
                color:white;
                font-weight:bold;
                padding:6px 12px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#22c55e;
            }
        """
        )
        connect_btn.clicked.connect(self.connect_server)
        bl.addWidget(connect_btn)

        disconnect_btn = QPushButton("Disconnect")
        disconnect_btn.setStyleSheet(
            """
            QPushButton {
                background:#dc2626;
                color:white;
                font-weight:bold;
                padding:6px 12px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#ef4444;
            }
        """
        )
        disconnect_btn.clicked.connect(self.disconnect_server)
        bl.addWidget(disconnect_btn)

        layout.addWidget(bar)

        # ---------- Top: Teacher → You ----------
        top = QWidget()
        top.setStyleSheet("background:#0f172a;")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(10, 10, 10, 5)
        tl.setSpacing(8)

        head = QHBoxLayout()
        head.addWidget(
            QLabel(
                "<font color='#cbd5f5'><b>Teacher → You (Translated Output):</b></font>"
            )
        )
        head.addStretch()

        dropdown_style = """
            QComboBox {
                background-color:#1e293b;
                color:#f1f5f9;
                border:1px solid #475569;
                border-radius:4px;
                padding:4px 6px;
                font-weight:500;
            }
            QComboBox:hover {
                border:1px solid #38bdf8;
            }
            QComboBox::drop-down {
                border:0px;
                width:22px;
            }
            QComboBox QAbstractItemView {
                background-color:#1e293b;
                color:#f8fafc;
                selection-background-color:#2563eb;
                selection-color:white;
            }
        """

        head.addWidget(QLabel("<font color='white'>Receive:</font>"))
        self.tgt_combo = QComboBox()
        self.tgt_combo.addItems(LANG_DISPLAY_LIST)
        self.tgt_combo.setCurrentText("Hindi")
        self.tgt_combo.setStyleSheet(dropdown_style)
        head.addWidget(self.tgt_combo)

        head.addSpacing(10)
        head.addWidget(QLabel("<font color='white'>Speak:</font>"))
        self.src_combo = QComboBox()
        self.src_combo.addItems(LANG_DISPLAY_LIST)
        self.src_combo.setCurrentText("Sinhala")
        self.src_combo.setStyleSheet(dropdown_style)
        head.addWidget(self.src_combo)

        tl.addLayout(head)

        self.tgt_box = QTextEdit()
        self.tgt_box.setReadOnly(True)
        self.tgt_box.setStyleSheet(
            "background:#111827;color:#93c5fd;font-family:'Segoe UI';font-size:22px;font-weight:600;"
        )
        tl.addWidget(self.tgt_box)

        layout.addWidget(top, 1)

        # ---------- Bottom: Transcript History ----------
        bottom = QWidget()
        bottom.setStyleSheet("background:#1e293b;")
        blay = QVBoxLayout(bottom)
        blay.setContentsMargins(10, 5, 10, 10)
        blay.setSpacing(4)

        blay.addWidget(
            QLabel("<font color='white'><b>Transcript History :</b></font>")
        )

        self.hist = QTextEdit()
        self.hist.setReadOnly(True)
        self.hist.setStyleSheet(
            "background:#111827;color:#e2e8f0;font-family:'Segoe UI';font-size:20px;font-weight:500;"
        )
        blay.addWidget(self.hist, 1)

        layout.addWidget(bottom, 1)

    # --------------------------------------------------------
    # Connection / mic
    # --------------------------------------------------------
    def connect_server(self):
        host = self.server.text().strip()
        if not host:
            QMessageBox.warning(self, "Server missing", "Please enter server host:port")
            return

        uri = "ws://" + host if not host.startswith("ws://") else host
        tgt_code = lang_to_code(self.tgt_combo.currentText())
        src_code = lang_to_code(self.src_combo.currentText())

        threading.Thread(
            target=lambda: asyncio.run(ws_downstream(uri, tgt_code)), daemon=True
        ).start()
        threading.Thread(
            target=lambda: asyncio.run(ws_upstream(uri, src_code)), daemon=True
        ).start()

        self.uri = uri
        self.ask_btn.setEnabled(True)

    def disconnect_server(self):
        # We rely on reconnect behaviour in workers; here we just stop mic & UI
        self.ask_btn.setEnabled(False)
        self.tgt_box.clear()

    def _audio_cb(self, indata, frames, time_info, status):
        if status:
            return
        self.rec_frames.append(indata[:, 0].copy())

    def _on_press(self):
        if self.rec_stream is not None:
            return
        UP_QUEUE.put({"type": "pause_mic", "state": True})
        self.rec_frames = []
        try:
            self.rec_stream = sd.InputStream(
                samplerate=self.rec_sr,
                channels=1,
                dtype="float32",
                callback=self._audio_cb,
            )
            self.rec_stream.start()
            self.ask_btn.setText("Release to send")
        except Exception as e:
            QMessageBox.warning(self, "Mic error", str(e))
            UP_QUEUE.put({"type": "pause_mic", "state": False})
            self.rec_stream = None

    def _on_release(self):
        if self.rec_stream is None:
            return
        try:
            self.rec_stream.stop()
            self.rec_stream.close()
        finally:
            self.rec_stream = None

        if not self.rec_frames:
            UP_QUEUE.put({"type": "pause_mic", "state": False})
            self.ask_btn.setText("Ask (press  hold)")
            return

        audio = np.concatenate(self.rec_frames, axis=0).astype(np.float32)
        if np.max(np.abs(audio)) < self.energy_gate:
            UP_QUEUE.put({"type": "pause_mic", "state": False})
            self.ask_btn.setText("Ask (press  hold)")
            return

        src_code = lang_to_code(self.src_combo.currentText())
        UP_QUEUE.put(
            {
                "type": "up_chunk",
                "sr": self.rec_sr,
                "src": src_code,
                "wav_b64": wav_b64_from_f32(audio, self.rec_sr),
            }
        )
        UP_QUEUE.put({"type": "pause_mic", "state": False})
        self.ask_btn.setText("Ask (press  hold)")

    # Poll & display messages
    def _poll(self):
        try:
            while True:
                data = DOWN_QUEUE.get_nowait()
                self._on_msg(data)
        except queue.Empty:
            pass

    def _on_msg(self, data: dict):
        current_tgt_code = lang_to_code(self.tgt_combo.currentText())
        if data.get("tgt") != current_tgt_code:
            return

        src_text = (data.get("src_text") or "").strip()
        tgt_text = (data.get("tgt_text") or "").strip()
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        src_lang = data.get("src", "")
        tgt_lang = data.get("tgt", "")

        # ---------------------------
        # FIX: append teacher chunks in the top box
        # ---------------------------
        existing = self.tgt_box.toPlainText().strip()
        if existing:
            new_text = existing + " " + tgt_text
        else:
            new_text = tgt_text

        self.tgt_box.setPlainText(new_text)
        self.tgt_box.moveCursor(self.tgt_box.textCursor().End)

        # ---------------------------
        # History (already good)
        # ---------------------------
        html_block = (
            f"<span style='color:#d1d5db;'>[{timestamp}]</span> "
            f"<b><span style='color:#38bdf8;font-size:18px;'>SRC({src_lang}):</span></b> "
            f"<span style='color:#e2e8f0;font-size:18px;'>{src_text}</span><br>"
            f"<b><span style='color:#22c55e;font-size:22px;'>→ TGT({tgt_lang}):</span></b> "
            f"<span style='color:#93c5fd;font-size:22px;font-weight:600;'>{tgt_text}</span><br><br>"
        )

        self.hist.moveCursor(self.hist.textCursor().End)
        self.hist.insertHtml(html_block)
        self.hist.moveCursor(self.hist.textCursor().End)

    # --------------------------------------------------------
    # Save transcript (HTML to preserve colours)
    # --------------------------------------------------------
    def save_transcript(self):
        html = self.hist.toHtml()
        if not html.strip():
            QMessageBox.information(self, "Save Transcript", "No transcript yet.")
            return
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        default_name = f"student_transcript_{ts}.html"
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Transcript",
            default_name,
            "HTML Files (*.html);;All Files (*)",
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(html)
            QMessageBox.information(self, "Saved", f"Transcript saved:\n{path}")


# ============================================================
def main():
    app = QApplication(sys.argv)
    w = StudentConsole()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
