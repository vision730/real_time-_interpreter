import asyncio
import threading
import sys
import io
import os
import socket
import ctypes

from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QTextEdit, QHBoxLayout, QVBoxLayout, QFrame, QMessageBox
)
from PyQt5.QtGui import (
    QFont, QPalette, QColor, QPixmap, QPainter,
    QTextCursor, QTextCharFormat
)
from PyQt5.QtCore import Qt, pyqtSignal, QObject, QTimer

import websockets  # pip install websockets

from server_ws_final import TeacherServer, MIC_PAUSED, WS_HOST, WS_PORT  # type: ignore


# ============ DPI Awareness (Must be set BEFORE QApplication) ============
def enable_dpi_awareness():
    if sys.platform == "win32":
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
            print("[DPI] Enabled Per-Monitor DPI Awareness V2")
        except:
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
                print("[DPI] Enabled Per-Monitor DPI Awareness")
            except:
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                    print("[DPI] Enabled System DPI Awareness")
                except:
                    print("[DPI] Could not enable DPI awareness")

enable_dpi_awareness()

GLOBAL_SERVER = None
GLOBAL_LOOP = None
GLOBAL_MIC_THREAD = None  


# ========= Header Widget (Auto-Scaling Title with DPI Support) ========= #
class HeaderWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(120)
        self.setMaximumHeight(150)

        base = os.path.dirname(os.path.abspath(__file__))
        self.bg = QPixmap(os.path.join(base, "ban1.jpg"))
        self.left_logo = QPixmap(os.path.join(base, "mcte.png"))
        self.right_logo = QPixmap(os.path.join(base, "NX1.png"))

    def sizeHint(self):
        return self.minimumSize()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setRenderHint(QPainter.Antialiasing)

        if not self.bg.isNull():
            p.drawPixmap(0, 0, self.width(), self.height(), self.bg)

        logo_height = int(self.height() * 0.65)
        logo_width = int(logo_height * 1.25)
        logo_margin = 15
        logo_y = (self.height() - logo_height) // 2

        if not self.left_logo.isNull():
            p.drawPixmap(
                logo_margin, logo_y,
                self.left_logo.scaled(logo_width, logo_height,
                                      Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )
        if not self.right_logo.isNull():
            p.drawPixmap(
                self.width() - logo_width - logo_margin, logo_y,
                self.right_logo.scaled(logo_width, logo_height,
                                       Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )

        cx = self.width() // 2
        base_font_size = max(24, min(38, int(self.height() * 0.28)))
        title_font = QFont("Segoe UI Black", base_font_size, QFont.Bold)
        p.setFont(title_font)
        fm = p.fontMetrics()

        title = "NirūpanaX"
        title_width = fm.width(title)
        available_width = self.width() - (2 * logo_width) - (4 * logo_margin)
        if title_width > available_width:
            scale_factor = available_width / title_width
            new_size = int(base_font_size * scale_factor * 0.95)
            title_font.setPointSize(new_size)
            p.setFont(title_font)
            fm = p.fontMetrics()
            title_width = fm.width(title)

        tx = cx - title_width // 2
        title_y = int(self.height() * 0.45)

        p.setPen(QColor("#49045C")); p.drawText(tx, title_y, "N")
        n_width = fm.width("N")
        p.setPen(QColor("#214F01")); p.drawText(tx + n_width, title_y, "irūpana")
        nirupana_width = fm.width("Nirūpana")
        p.setPen(QColor("#49045C")); p.drawText(tx + nirupana_width, title_y, "X")

        sub = "One Classroom. Many Languages. Zero Barriers."
        sub_font_size = max(12, min(20, int(self.height() * 0.15)))
        sub_font = QFont("Brush Script MT", sub_font_size, QFont.Normal, italic=True)
        p.setFont(sub_font)
        p.setPen(QColor("#053F5B"))
        sub_y = int(self.height() * 0.78)
        p.drawText(cx - p.fontMetrics().width(sub) // 2, sub_y, sub)
        p.end()

class LogEmitter(QObject):
    message = pyqtSignal(str)


class GuiLogger(io.TextIOBase):
    BANNED = {'✓', '⚠', '✗', '✔', '❌', '🚫', '⚡', '★', '☆'}

    def __init__(self, emitter: LogEmitter, original_stream):
        super().__init__()
        self.emitter = emitter
        self.original_stream = original_stream

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        filtered = "".join(ch for ch in s if ch not in self.BANNED and (ch.isprintable() or ch in '\n\r\t'))
        try:
            self.original_stream.write(filtered)
        except Exception:
            pass
        try:
            self.emitter.message.emit(filtered)
        except Exception:
            pass
        return len(s)

    def flush(self):
        try:
            self.original_stream.flush()
        except Exception:
            pass


# ========= Helper: Detect IP ========= #
def get_current_ip():
    if WS_HOST not in ("0.0.0.0", "", "localhost", "127.0.0.1"):
        return WS_HOST
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


# ========= Server Thread ========= #
def _async_cancel_all(loop: asyncio.AbstractEventLoop):
    # helper to cancel all tasks on a loop
    try:
        pending = asyncio.all_tasks(loop)
    except RuntimeError:
        pending = set()
    for t in pending:
        t.cancel()
    if pending:
        try:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        except Exception:
            pass


def run_server_in_thread(stop_event: threading.Event):
    global GLOBAL_SERVER, GLOBAL_LOOP, GLOBAL_MIC_THREAD

    server = TeacherServer()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    GLOBAL_SERVER = server
    GLOBAL_LOOP = loop

    async def main():
        async with websockets.serve(
            server.handler, WS_HOST, WS_PORT,
            ping_interval=20, ping_timeout=20, max_size=8 * 1024 * 1024
        ):
            print(f"[WS] Server listening on ws://{WS_HOST}:{WS_PORT}")
            asyncio.create_task(server._broadcaster())

            mic_thread = threading.Thread(target=server._mic_loop, args=(loop,), daemon=True)
            mic_thread.start()
            GLOBAL_MIC_THREAD = mic_thread
            print("[Mic] Thread started")

            while not stop_event.is_set():
                await asyncio.sleep(0.5)
            print("[WS] Stop requested from GUI")

    try:
        loop.run_until_complete(main())
    except Exception as e:
        print(f"[WS] Server thread error: {e}")
    finally:
        _async_cancel_all(loop)
        try:
            loop.stop()
        except Exception:
            pass
        try:
            loop.close()
        except Exception:
            pass
        print("[WS] Event loop closed")


class ServerWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NirūpanaX – Server Console")

        self.setMinimumSize(1200, 700)
        self.resize(1350, 800)

        self.server_thread = None
        self.stop_event = None
        self.server_running = False
        self.mic_on = True

        self.log_emitter = LogEmitter()
        self.log_emitter.message.connect(self.append_text)
        self._orig_stdout = sys.stdout
        self._orig_stderr = sys.stderr
        sys.stdout = GuiLogger(self.log_emitter, self._orig_stdout)
        sys.stderr = GuiLogger(self.log_emitter, self._orig_stderr)

        self.apply_theme()
        self.build_ui()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_stats)
        self.timer.start(10_000)
        self.update_stats()

    def apply_theme(self):
        pal = QPalette()
        pal.setColor(QPalette.Window, QColor("#020617"))
        pal.setColor(QPalette.Base, QColor("#020617"))
        pal.setColor(QPalette.Text, Qt.white)
        self.setPalette(pal)

    def button_style(self, bg, fg="#fff"):
        return f"""
            QPushButton {{
                background-color:{bg};
                color:{fg};
                font-weight:bold;
                padding:6px 14px;
                border-radius:6px;
                min-height:28px;
            }}
            QPushButton:hover {{
                background-color:#1d4ed8;
            }}
            QPushButton:disabled {{
                background-color:#374151;
                color:#6b7280;
            }}
        """

    def build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(HeaderWidget())

        control_frame = QFrame()
        control_frame.setStyleSheet("background-color:#0f172a;")
        control_layout = QHBoxLayout(control_frame)
        control_layout.setContentsMargins(15, 8, 15, 8)
        control_layout.setSpacing(10)

        self.btn_start = QPushButton("Start Server")
        self.btn_start.setStyleSheet(self.button_style("#2563eb"))
        self.btn_start.clicked.connect(self.start_server)
        control_layout.addWidget(self.btn_start)

        self.btn_stop = QPushButton("Stop Server")
        self.btn_stop.setEnabled(False)
        self.btn_stop.setStyleSheet(self.button_style("#dc2626"))
        self.btn_stop.clicked.connect(self.stop_server)
        control_layout.addWidget(self.btn_stop)

        self.btn_mic = QPushButton("Mic: ON")
        self.btn_mic.setEnabled(False)
        self.btn_mic.setStyleSheet(self.button_style("#1e293b"))
        self.btn_mic.clicked.connect(self.toggle_mic)
        control_layout.addWidget(self.btn_mic)

        control_layout.addStretch(1)

        self.btn_clear = QPushButton("Clear Log")
        self.btn_clear.setStyleSheet(self.button_style("#1e293b"))
        self.btn_clear.clicked.connect(lambda: self.log.clear())
        control_layout.addWidget(self.btn_clear)

        layout.addWidget(control_frame)

        info_layout = QHBoxLayout()
        info_layout.setContentsMargins(15, 8, 15, 8)
        self.status = QLabel("Status: STOPPED")
        self.status.setFont(QFont("Segoe UI Semibold", 11))
        self.status.setStyleSheet("color:#fbbf24;")
        info_layout.addWidget(self.status)
        info_layout.addStretch(1)
        self.ip_label = QLabel("IP: -")
        self.ip_label.setStyleSheet("color:#f1f5f9;")
        info_layout.addWidget(self.ip_label)
        self.student_label = QLabel(" Students connected: 0")
        self.student_label.setStyleSheet("color:#4ade80;")
        info_layout.addWidget(self.student_label)
        layout.addLayout(info_layout)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setFont(QFont("Consolas", 10))
        self.log.setStyleSheet(
            "QTextEdit{background-color:#000; color:#E5E7EB; border:1px solid #1f2937; border-radius:6px; margin:10px;}"
        )
        layout.addWidget(self.log)

    # ========== Server control ==========
    def start_server(self):
        if self.server_running:
            return
        self.stop_event = threading.Event()
        # Non-daemon so we can join reliably
        self.server_thread = threading.Thread(
            target=run_server_in_thread, args=(self.stop_event,), daemon=False
        )
        self.server_thread.start()
        self.server_running = True
        self.mic_on = True
        MIC_PAUSED.clear()
        self.status.setText("Status: RUNNING")
        self.status.setStyleSheet("color:#22c55e;")
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.btn_mic.setEnabled(True)
        print("=" * 70)
        print("NirupanaX – REAL-TIME INTERPRETER SERVER")
        print("=" * 70)

    def _force_kill_thread(self, th: threading.Thread):
        if not th or not th.is_alive():
            return
        # Find thread id
        for tid, tobj in threading._active.items():
            if tobj is th:
                try:
                    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(tid), ctypes.py_object(SystemExit))
                    if res == 0:
                        print("[Mic] Force-kill failed: no thread state")
                    elif res > 1:
                        # revert if it affected more than one thread
                        ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(tid), 0)
                        print("[Mic] Force-kill reverted (affected multiple threads)")
                    else:
                        print("[Mic] Mic thread terminated via SystemExit")
                except Exception as e:
                    print(f"[Mic] Force-kill error: {e}")
                break

    def stop_server(self):
        global GLOBAL_SERVER, GLOBAL_LOOP, GLOBAL_MIC_THREAD

        if not self.server_running:
            return

        print("[GUI] Stop requested... halting mic & server")

        try:
            MIC_PAUSED.set()
        except Exception:
            pass

        if self.stop_event:
            self.stop_event.set()

        if GLOBAL_MIC_THREAD and GLOBAL_MIC_THREAD.is_alive():
            GLOBAL_MIC_THREAD.join(timeout=1.5)

        if GLOBAL_MIC_THREAD and GLOBAL_MIC_THREAD.is_alive():
            self._force_kill_thread(GLOBAL_MIC_THREAD)

        GLOBAL_MIC_THREAD = None

        # Join server thread
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=3.0)

        # Cleanup asyncio loop
        if GLOBAL_LOOP is not None:
            try:
                GLOBAL_LOOP.call_soon_threadsafe(GLOBAL_LOOP.stop)
            except Exception:
                pass
            try:
                GLOBAL_LOOP.close()
            except Exception:
                pass

        # Null out globals so nothing can poke a dead loop
        GLOBAL_SERVER = None
        GLOBAL_LOOP = None

        # --- UI updates ---
        self.server_running = False
        self.status.setText("Status: STOPPED")
        self.status.setStyleSheet("color:#fbbf24;")
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.btn_mic.setEnabled(False)
        self.student_label.setText("Students connected: 0")
        print("[GUI] Server stopped cleanly and will not restart automatically.")

    def toggle_mic(self):
        if not self.server_running:
            return
        self.mic_on = not self.mic_on
        if self.mic_on:
            MIC_PAUSED.clear()
            self.btn_mic.setText("Mic: ON")
            print("[GUI] Mic resumed")
        else:
            MIC_PAUSED.set()
            self.btn_mic.setText("Mic: OFF")
            print("[GUI] Mic paused")

    # ========== Stats ==========
    def update_stats(self):
        ip = get_current_ip()
        self.ip_label.setText(f"IP: ws://{ip}:{WS_PORT}")
        if not self.server_running:
            self.student_label.setText("  Students connected: 0")
            return

        groups = "0"
        if GLOBAL_SERVER and GLOBAL_LOOP:
            try:
                fut = asyncio.run_coroutine_threadsafe(GLOBAL_SERVER._snapshot_clients(), GLOBAL_LOOP)
                snap = fut.result(timeout=0.5)
                student_sockets = sum(1 for i in snap.values() if i.get("role") == "student")
                groups = str(student_sockets // 2)
            except Exception:
                groups = "N/A"
        self.student_label.setText(f"Students connected: {groups}")

    # ========== Log ==========
    def append_text(self, text):
        if not text:
            return
        cursor = self.log.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = QTextCharFormat()
        fmt.setForeground(QColor("#E5E7EB"))
        cursor.setCharFormat(fmt)
        cursor.insertText(text)
        self.log.setTextCursor(cursor)
        self.log.ensureCursorVisible()

    def closeEvent(self, event):
        if self.server_running:
            if QMessageBox.question(self, "Exit", "Server is running. Stop and exit?",
                                    QMessageBox.Yes | QMessageBox.No) == QMessageBox.No:
                event.ignore()
                return
            self.stop_server()
        sys.stdout = self._orig_stdout
        sys.stderr = self._orig_stderr
        event.accept()


def main():
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    win = ServerWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
