import sys, os, asyncio, threading, queue, json, io, base64, wave, datetime
import numpy as np
import sounddevice as sd
import websockets

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QComboBox, QFileDialog, QMessageBox,
    QLineEdit
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap, QPainter, QFont, QColor

# ============================================================
# Queues – WebSocket ↔ GUI
# ============================================================
DOWN_QUEUE = queue.Queue()
UP_QUEUE = queue.Queue()

LANG_MAP = {
    "English": "eng",
    "Hindi": "hin",
    "Sinhala": "sin",
    "Nepali": "nep",
    "Vietnamese": "vie",
    "Malayalam": "mal",
}
LANG_DISPLAY_LIST = list(LANG_MAP.keys())


def lang_to_code(name: str) -> str:
    return LANG_MAP.get(name, "eng")


# ============================================================
# Audio helper: convert PCM float32 <-> wav bytes
# ============================================================
def float32_to_wav_bytes(float32_audio: np.ndarray, sr: int = 16000) -> bytes:
    audio_int16 = np.clip(float32_audio * 32767.0, -32768, 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(audio_int16.tobytes())
    return buf.getvalue()


# ============================================================
# WebSocket background worker
# ============================================================
async def ws_worker(uri: str, tgt_lang_code: str):
    """
    Runs in a separate thread event loop.
    Receives:
      - "DOWN_QUEUE" messages from server (translation, etc.)
    Sends:
      - "UP_QUEUE" messages from GUI (audio chunks, target lang, role).
    """
    print(f"[WS] Connecting to {uri} ...")
    try:
        async with websockets.connect(uri, max_size=20 * 1024 * 1024) as ws:
            print("[WS] Connected.")

            # Initial handshake: tell server that we're a student and our language
            hello_msg = {
                "type": "hello",
                "role": "student",
                "tgt": tgt_lang_code,
            }
            await ws.send(json.dumps(hello_msg))

            async def sender():
                while True:
                    msg = await asyncio.get_event_loop().run_in_executor(
                        None, UP_QUEUE.get
                    )
                    if msg is None:
                        break
                    try:
                        await ws.send(msg)
                    except Exception as e:
                        print("[WS] Sender error:", e)
                        break

            async def receiver():
                while True:
                    try:
                        data = await ws.recv()
                    except Exception as e:
                        print("[WS] Receiver error:", e)
                        break
                    try:
                        obj = json.loads(data)
                    except json.JSONDecodeError:
                        print("[WS] Bad JSON from server")
                        continue
                    DOWN_QUEUE.put(obj)

            sender_task = asyncio.create_task(sender())
            recv_task = asyncio.create_task(receiver())
            await asyncio.wait(
                [sender_task, recv_task], return_when=asyncio.FIRST_COMPLETED
            )

    except Exception as e:
        print("[WS] Could not connect or error in loop:", e)

    finally:
        DOWN_QUEUE.put({"type": "status", "msg": "disconnected"})
        print("[WS] Disconnected.")


def start_ws_thread(uri: str, tgt_lang_code: str):
    """
    Launch the ws_worker in a separate daemon thread with its own event loop.
    """
    def runner():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(ws_worker(uri, tgt_lang_code))
        loop.close()

    t = threading.Thread(target=runner, daemon=True)
    t.start()


# ============================================================
# Recording utility using sounddevice
# ============================================================
class Recorder:
    def __init__(self, student_gui, samplerate=16000, blocksize=1024):
        self.student_gui = student_gui
        self.samplerate = samplerate
        self.blocksize = blocksize
        self.stream = None
        self.is_recording = False
        self.frames = []

    def _callback(self, indata, frames, time, status):
        if status:
            print("[Mic] Status:", status)
        if self.is_recording:
            mono = indata[:, 0].copy()
            self.frames.append(mono)

    def start(self):
        if self.stream is not None:
            return
        self.frames = []
        self.is_recording = True
        self.stream = sd.InputStream(
            channels=1,
            samplerate=self.samplerate,
            blocksize=self.blocksize,
            callback=self._callback,
        )
        self.stream.start()
        print("[Mic] Recording started")

    def stop(self):
        if self.stream is None:
            return None
        self.is_recording = False
        self.stream.stop()
        self.stream.close()
        self.stream = None
        print("[Mic] Recording stopped")

        if not self.frames:
            return None
        audio = np.concatenate(self.frames, axis=0)
        self.frames = []
        return audio


# ============================================================
# Main Student GUI
# ============================================================
class StudentConsole(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Nirūpana – Student Console")
        self.resize(950, 750)

        self.connected = False
        self.uri = ""
        self.rec_sr = 16000
        self.rec_frames = []
        self.rec_stream = None
        self.energy_gate = 0.01

        # Buffers to accumulate full text (no skipping)
        self.full_src_text = ""
        self.full_tgt_text = ""

        self._build_ui()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll)
        self.timer.start(80)

    # --------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 8)
        main_layout.setSpacing(4)

        # ------------------ Header banner ------------------
        header = QWidget()
        header.setFixedHeight(120)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(10, 10, 10, 10)
        hl.setSpacing(10)

        base = os.path.dirname(os.path.abspath(__file__))
        bg_path = os.path.join(base, "ban1.jpg")
        self.bg_pix = QPixmap(bg_path)

        left_logo = QLabel()
        ll_path = os.path.join(base, "VX1.png")
        lp = QPixmap(ll_path)
        if not lp.isNull():
            left_logo.setPixmap(lp.scaled(100, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        hl.addWidget(left_logo, 0, Qt.AlignLeft | Qt.AlignVCenter)

        title_label = QLabel("Nirūpana – Student Console")
        title_font = QFont("Segoe UI", 20, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setStyleSheet("color: white;")
        title_label.setAlignment(Qt.AlignCenter)
        hl.addWidget(title_label, 1, Qt.AlignCenter)

        right_logo = QLabel()
        rl_path = os.path.join(base, "mcte.png")
        rp = QPixmap(rl_path)
        if not rp.isNull():
            right_logo.setPixmap(rp.scaled(100, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        hl.addWidget(right_logo, 0, Qt.AlignRight | Qt.AlignVCenter)

        # Paint the background banner behind header using a wrapper
        wrapper = BannerWrapper(widget=header, pixmap=self.bg_pix)
        main_layout.addWidget(wrapper)

        # ------------------ Connection bar ------------------
        conn_bar = QWidget()
        cb_layout = QHBoxLayout(conn_bar)
        cb_layout.setContentsMargins(10, 0, 10, 0)
        cb_layout.setSpacing(8)

        cb_layout.addWidget(QLabel("Server:"))
        self.server_edit = QLineEdit("ws://127.0.0.1:8765")
        self.server_edit.setMinimumWidth(240)
        cb_layout.addWidget(self.server_edit)

        cb_layout.addWidget(QLabel("Your language:"))
        self.tgt_combo = QComboBox()
        self.tgt_combo.addItems(LANG_DISPLAY_LIST)
        self.tgt_combo.setCurrentText("Hindi")
        cb_layout.addWidget(self.tgt_combo)

        self.status_label = QLabel("Disconnected")
        self.status_label.setStyleSheet("color:#ef4444;font-weight:bold;")
        cb_layout.addWidget(self.status_label)

        cb_layout.addStretch(1)

        connect_btn = QPushButton("Connect")
        connect_btn.setStyleSheet(
            """
            QPushButton {
                background:#22c55e;
                color:white;
                font-weight:bold;
                padding:6px 14px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#16a34a;
            }
        """
        )
        connect_btn.clicked.connect(self.connect_server)
        cb_layout.addWidget(connect_btn)

        disconnect_btn = QPushButton("Disconnect")
        disconnect_btn.setStyleSheet(
            """
            QPushButton {
                background:#dc2626;
                color:white;
                font-weight:bold;
                padding:6px 14px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#b91c1c;
            }
        """
        )
        disconnect_btn.clicked.connect(self.disconnect_server)
        cb_layout.addWidget(disconnect_btn)

        main_layout.addWidget(conn_bar)

        # ------------------ Top translation area ------------------
        top_area = QWidget()
        top_layout = QVBoxLayout(top_area)
        top_layout.setContentsMargins(10, 0, 10, 0)
        top_layout.setSpacing(4)

        lbl = QLabel("Teacher  →  You")
        lbl.setStyleSheet("color:#e5e7eb;font-size:16px;font-weight:bold;")
        top_layout.addWidget(lbl)

        self.tgt_box = QTextEdit()
        self.tgt_box.setReadOnly(True)
        self.tgt_box.setStyleSheet(
            """
            QTextEdit {
                background:#020617;
                color:#e5e7eb;
                border:1px solid #1e293b;
                border-radius:4px;
                font-size:22px;
                padding:8px;
            }
        """
        )
        top_layout.addWidget(self.tgt_box, 1)

        main_layout.addWidget(top_area, 2)

        # ------------------ Bottom transcript & ask bar ------------------
        bottom = QWidget()
        b_layout = QVBoxLayout(bottom)
        b_layout.setContentsMargins(10, 0, 10, 0)
        b_layout.setSpacing(6)

        # Transcript area
        b_layout.addWidget(QLabel("Full Transcript"))
        self.hist = QTextEdit()
        self.hist.setReadOnly(True)
        self.hist.setStyleSheet(
            """
            QTextEdit {
                background:#0f172a;
                color:#e2e8f0;
                border:1px solid #1f2937;
                border-radius:4px;
                font-size:14px;
                padding:8px;
            }
        """
        )
        b_layout.addWidget(self.hist, 3)

        # Ask/record area
        ask_bar = QWidget()
        bl = QHBoxLayout(ask_bar)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(8)

        self.ask_btn = QPushButton("Hold to Ask")
        self.ask_btn.setCheckable(True)
        self.ask_btn.setStyleSheet(
            """
            QPushButton {
                background:#3b82f6;
                color:white;
                font-weight:bold;
                padding:8px 18px;
                border-radius:999px;
            }
            QPushButton:pressed {
                background:#1d4ed8;
            }
            QPushButton:checked {
                background:#1d4ed8;
            }
        """
        )
        self.ask_btn.pressed.connect(self._on_press)
        self.ask_btn.released.connect(self._on_release)
        bl.addWidget(self.ask_btn)

        save_btn = QPushButton("Save Transcript")
        save_btn.setStyleSheet(
            """
            QPushButton {
                background:#475569;
                color:white;
                font-weight:bold;
                padding:6px 14px;
                border-radius:4px;
            }
            QPushButton:hover {
                background:#334155;
            }
        """
        )
        save_btn.clicked.connect(self.save_transcript)
        bl.addWidget(save_btn)

        bl.addStretch(1)
        b_layout.addWidget(ask_bar)

        main_layout.addWidget(bottom, 3)

        # Make a recorder instance
        self.recorder = Recorder(self, samplerate=self.rec_sr, blocksize=1024)

        # Dark background
        self.setStyleSheet("QMainWindow { background-color:#020617; }")

    # --------------------------------------------------------
    def connect_server(self):
        if self.connected:
            return
        self.uri = self.server_edit.text().strip()
        if not self.uri:
            QMessageBox.warning(self, "Error", "Please enter server URI.")
            return

        tgt_lang_name = self.tgt_combo.currentText()
        tgt_code = lang_to_code(tgt_lang_name)
        self.status_label.setText("Connecting...")
        self.status_label.setStyleSheet("color:#eab308;font-weight:bold;")

        start_ws_thread(self.uri, tgt_code)
        self.connected = True

    def disconnect_server(self):
        if not self.connected:
            return
        self.connected = False
        UP_QUEUE.put(None)
        self.status_label.setText("Disconnected")
        self.status_label.setStyleSheet("color:#ef4444;font-weight:bold;")

    # --------------------------------------------------------
    def _on_press(self):
        if not self.connected:
            QMessageBox.information(self, "Info", "Connect to server first.")
            self.ask_btn.setChecked(False)
            return
        self.ask_btn.setText("Listening...")
        self.recorder.start()

    def _on_release(self):
        if not self.connected:
            self.ask_btn.setChecked(False)
            self.ask_btn.setText("Hold to Ask")
            return
        audio = self.recorder.stop()
        self.ask_btn.setChecked(False)
        self.ask_btn.setText("Hold to Ask")

        if audio is None or len(audio) == 0:
            print("[Ask] No audio captured.")
            return

        rms = float(np.sqrt(np.mean(audio ** 2)))
        if rms < self.energy_gate:
            print("[Ask] Audio too silent, ignoring.")
            return

        wav_bytes = float32_to_wav_bytes(audio, sr=self.rec_sr)
        b64_audio = base64.b64encode(wav_bytes).decode("ascii")

        tgt_lang_name = self.tgt_combo.currentText()
        tgt_code = lang_to_code(tgt_lang_name)

        up_msg = {
            "type": "st_ask",
            "role": "student",
            "audio_b64": b64_audio,
            "tgt": tgt_code,
        }
        UP_QUEUE.put(json.dumps(up_msg))

    # --------------------------------------------------------
    def _poll(self):
        """
        Periodically read from DOWN_QUEUE to update GUI.
        """
        while True:
            try:
                data = DOWN_QUEUE.get_nowait()
            except queue.Empty:
                break
            self._handle_msg(data)

    def _handle_msg(self, data: dict):
        t = data.get("type", "")
        if t == "status":
            msg = data.get("msg", "")
            if msg == "disconnected":
                self.connected = False
                self.status_label.setText("Disconnected")
                self.status_label.setStyleSheet("color:#ef4444;font-weight:bold;")
            return
        if t == "trans":
            self._on_msg(data)

    def _on_msg(self, data: dict):
        current_tgt_code = lang_to_code(self.tgt_combo.currentText())
        if data.get("tgt") != current_tgt_code:
            return

        src_text = (data.get("src_text") or "").strip()
        tgt_text = (data.get("tgt_text") or "").strip()
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        src_lang = data.get("src", "")
        tgt_lang = data.get("tgt", "")

        # --- Accumulate full text from first word to last ---
        if src_text:
            self.full_src_text = (self.full_src_text + " " + src_text).strip()
        if tgt_text:
            self.full_tgt_text = (self.full_tgt_text + " " + tgt_text).strip()

        # Show full translation so far in the top box
        self.tgt_box.setPlainText(self.full_tgt_text)

        # History: colored SRC/TGT with different font size (chunk-wise)
        html_block = (
            f"<span style='color:#d1d5db;'>[{timestamp}]</span> "
            f"<b><span style='color:#38bdf8;font-size:18px;'>SRC({src_lang}):</span></b> "
            f"<span style='color:#e2e8f0;font-size:18px;'>{src_text}</span><br>"
            f"<b><span style='color:#22c55e;font-size:22px;'>→ TGT({tgt_lang}):</span></b> "
            f"<span style='color:#93c5fd;font-size:22px;font-weight:600;'>{tgt_text}</span><br><br>"
        )

        self.hist.moveCursor(self.hist.textCursor().End)
        self.hist.insertHtml(html_block)
        self.hist.moveCursor(self.hist.textCursor().End)

    # --------------------------------------------------------
    # Save transcript (HTML to preserve colours)
    # --------------------------------------------------------
    def save_transcript(self):
        html = self.hist.toHtml()
        if not html.strip():
            QMessageBox.information(self, "Save Transcript", "No transcript yet.")
            return
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        default_name = f"student_transcript_{ts}.html"
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Transcript As",
            default_name,
            "HTML Files (*.html);;All Files (*)",
        )
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(html)
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not save:\n{e}")
                return
            QMessageBox.information(self, "Saved", f"Transcript saved:\n{path}")


# ============================================================
# Wrapper to paint banner under a widget
# ============================================================
class BannerWrapper(QWidget):
    def __init__(self, widget: QWidget, pixmap: QPixmap, parent=None):
        super().__init__(parent)
        self.widget = widget
        self.pixmap = pixmap
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.widget)

    def paintEvent(self, event):
        painter = QPainter(self)
        if not self.pixmap.isNull():
            painter.drawPixmap(0, 0, self.width(), self.height(), self.pixmap)
        super().paintEvent(event)


# ============================================================
def main():
    app = QApplication(sys.argv)
    w = StudentConsole()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
